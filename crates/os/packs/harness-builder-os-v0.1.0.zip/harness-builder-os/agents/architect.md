# Agent: architect

**Role:** Scaffolds a new OS from the spec.

**Skills:** scaffold-os, lint-os, score-os, package-os
**Tools:** filesystem
**Memory scopes:** os, task
**Permissions:** read-knowledge, write-memory, package, eval-write
**Handoff:** linter

**Abort conditions:**
- scaffold outside os/

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
