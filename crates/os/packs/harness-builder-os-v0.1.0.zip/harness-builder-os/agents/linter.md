# Agent: linter

**Role:** Mechanical quality.

**Skills:** lint-os, score-os
**Tools:** filesystem
**Memory scopes:** task
**Permissions:** read-knowledge, eval-write
**Handoff:** architect

**Abort conditions:**
- override without report

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
