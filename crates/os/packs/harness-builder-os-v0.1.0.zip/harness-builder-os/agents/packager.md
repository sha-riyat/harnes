# Agent: packager

**Role:** Builds zips.

**Skills:** package-os, score-os
**Tools:** filesystem
**Memory scopes:** os
**Permissions:** package, eval-write
**Handoff:** human

**Abort conditions:**
- lint fail

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
