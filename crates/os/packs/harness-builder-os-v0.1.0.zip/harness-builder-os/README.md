# Harness Builder OS

Assemble, lint, score, and package OS harnesses so a domain pack is a zip, not a prompt paste.

Wave 0 factory OS. Load `manifest.yaml`. Doctrine in `OS.md`. Judgments in `oracle/ORACLE.md`.

Depends on: librarian-os, knowledge-builder-os, evaluation-os, agent-os, orchestration-os.

Confidence: B. Quality target ≥90, floor 7 per category.

## Quick start
1. Lint: `python3 scripts/lint-os.py --os harness-builder-os`
2. Route an intent from `routing/intents.yaml`
3. Run a skill under `skills/`
4. Score with `evals/suite.yaml`
