# Command /lint

**Use:** Lint an OS tree.
**Invokes:** lint-os
**Input:** path
**Output artifact type:** lint-report
**Refuse when:** path missing
