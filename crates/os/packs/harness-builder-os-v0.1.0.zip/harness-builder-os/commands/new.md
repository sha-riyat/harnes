# Command /new

**Use:** Scaffold an OS.
**Invokes:** scaffold-os
**Input:** id + purpose
**Output artifact type:** scaffold
**Refuse when:** id not matching *-os
