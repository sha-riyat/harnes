# Command /zip

**Use:** Package zip.
**Invokes:** package-os
**Input:** path
**Output artifact type:** zip-artifact
**Refuse when:** lint fail
