# Command /score

**Use:** Score quality.
**Invokes:** score-os
**Input:** path
**Output artifact type:** quality-score
**Refuse when:** no manifest
