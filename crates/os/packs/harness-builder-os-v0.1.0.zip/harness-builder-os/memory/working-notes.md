Phase 0 harness-builder-os implements lint/score/zip via scripts.
