    # Skill: lint-os

    **Purpose:** Check layout, schemas, forbidden tokens, adapter presence.

    **When to use:** Before score and zip.

    **Steps:**
    1. Walk os-spec required paths.
2. JSON-schema check where present.
3. Scan unfinished stub markers and filler prose.
4. Check adapter stubs.

    **Failure modes:**
    - Broken JSON

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
