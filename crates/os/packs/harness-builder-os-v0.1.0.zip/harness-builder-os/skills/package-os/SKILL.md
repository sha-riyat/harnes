    # Skill: package-os

    **Purpose:** Zip the OS or the library.

    **When to use:** Lint ok and gate ship.

    **Steps:**
    1. Exclude PDFs and vcs.
2. Write dist/ path.
3. Record version from VERSION.
4. Emit zip-artifact.

    **Failure modes:**
    - Lint not ok

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
