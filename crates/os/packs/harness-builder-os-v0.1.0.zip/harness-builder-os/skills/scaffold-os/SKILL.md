    # Skill: scaffold-os

    **Purpose:** Create canonical directories and starter files without unfinished stub markers.

    **When to use:** New OS id approved by librarian coverage map.

    **Steps:**
    1. Validate id pattern.
2. Write OS.md, manifest, oracle, adapters stubs.
3. Add empty-but-real evals and routing.
4. Register in factory if requested.

    **Failure modes:**
    - Existing id
- Invalid id

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
