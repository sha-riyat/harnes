    # Skill: score-os

    **Purpose:** Produce category scores and overall.

    **When to use:** Lint ran.

    **Steps:**
    1. Score layout, schemas, knowledge, research, agents_skills, workflows, evals, adapters, evidence, packaging.
2. Apply floor 7 warning.
3. Write dashboard fragment.

    **Failure modes:**
    - Scoring without lint

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
