# Playbook: english-mit

Released files English. LICENSE MIT. Version from VERSION file.
