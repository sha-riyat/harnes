# Playbook: honest-thin

If a section is thin, write an honest confidence D-E paragraph, not an unfinished stub. Thin research is valid; fake lists are not.
