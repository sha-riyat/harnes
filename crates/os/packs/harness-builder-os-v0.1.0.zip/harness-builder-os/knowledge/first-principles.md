# First principles — harness-builder-os

1. A harness is seams, fixtures, evals, and stop rules (Ousterhout, Humble/Farley).
2. A wrapper is not a platform.
3. Tests and delivery rails are the product around the product (Evans, Newman).
4. Flaky suites train people to ignore red.
5. Only harness systems you are authorized to touch.
6. No exploit or attack harness.
7. Failure injection is for systems you operate.
8. Humans gate production where harm is high.
9. No promised quality from a demo harness.
10. Anti-guru: no clean-code religion as a harness; no agent-wrapper merch.
