# Quality gate

evaluation-os plus mechanical linter. Both must pass.
