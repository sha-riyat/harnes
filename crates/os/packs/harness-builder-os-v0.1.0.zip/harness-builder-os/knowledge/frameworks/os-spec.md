# Canonical OS spec

factory/os-spec.md is the construction standard. Scaffold, lint, and zip all read it.
