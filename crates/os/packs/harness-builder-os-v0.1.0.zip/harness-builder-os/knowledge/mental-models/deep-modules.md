# Deep modules

Ousterhout: small interface, deep capability. An OS should expose few commands that do real work, not dozens of shallow prompts.
