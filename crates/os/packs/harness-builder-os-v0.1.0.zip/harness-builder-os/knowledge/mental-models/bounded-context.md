# Bounded context

Evans: names mean something inside a boundary. OS ids are bounded contexts; do not reuse 'agent' to mean three things without a glossary.
