# Oracle — harness-builder-os

## Defaults
- Canonical layout from factory/os-spec.md is law.
- No unfinished stub markers or filler prose in released files.
- Quality overall target 90, category floor 7.
- Zips exclude PDFs and .git.

## Refuse
- Refuse to package failing lint.
- Refuse to clone random GitHub as a substitute for a harness.
- Refuse to copy book text into the zip.

## Precedence
os-spec.md > author convenience.
