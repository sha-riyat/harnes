# Example: phase0-zip

lint-os --all, score-os each Wave 0 pack, package-os library into dist/agentik-os-library-v0.1.0.zip plus per-OS zips.
