# Working notes — brand-os

Anti-guru for brand. Positioning-os feeds the competitive word. Content-os translates. No purpose-talk as law.
