# First principles — brand-os

1. Brand equity is memory plus a kept promise, not a logo.
2. Mental and physical availability beat loyalty mythology for many mass categories (How Brands Grow).
3. Architecture (house of brands vs branded house) is a portfolio decision.
4. Distinctive brand assets are designed and measured.
5. Employer and product brands can conflict; name the audience.
6. Line extensions tax the parent word.
7. Critique (No Logo, surveillance) is part of literacy, not an optional vibe.
8. Measurement needs a dictionary; NPS is not the brand.
9. No promised brand love or zealot army.
10. Anti-guru: no archetype merch, no Lovemarks as law.
