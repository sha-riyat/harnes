# Aaker identity system

Four perspectives, core/extended, value proposition, credibility.
