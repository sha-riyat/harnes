# Distinctive asset grid

Fame x uniqueness. Romaniuk/Sharp.
