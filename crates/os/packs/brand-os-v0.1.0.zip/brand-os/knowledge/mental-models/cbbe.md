# CBBE pyramid

Salience to resonance. Climb with evidence.
