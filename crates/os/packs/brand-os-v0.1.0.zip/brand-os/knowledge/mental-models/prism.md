# Identity prism

Sender vs receiver facets. Diagnostic, not a poster.
