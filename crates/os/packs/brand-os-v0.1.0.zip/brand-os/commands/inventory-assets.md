# Command /inventory-assets

**Use:** Inventory distinctive brand assets.
**Invokes:** inventory-assets
**Input:** cues
**Output artifact type:** inventory-assets-artifact
**Refuse when:** Asset theater without fame/uniqueness
