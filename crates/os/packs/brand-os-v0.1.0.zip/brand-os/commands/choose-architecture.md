# Command /choose-architecture

**Use:** Choose branded house / house of brands / hybrid with roles.
**Invokes:** choose-architecture
**Input:** portfolio
**Output artifact type:** choose-architecture-artifact
**Refuse when:** Casual sub-branding
