# Command /snapshot-equity

**Use:** Snapshot customer-based equity with holes.
**Invokes:** snapshot-equity
**Input:** evidence
**Output artifact type:** snapshot-equity-artifact
**Refuse when:** Love-brand as the only measure
