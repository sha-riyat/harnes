# Command /draft-identity

**Use:** Draft core and extended identity pillars.
**Invokes:** draft-identity
**Input:** org
**Output artifact type:** draft-identity-artifact
**Refuse when:** Logo packet as identity
