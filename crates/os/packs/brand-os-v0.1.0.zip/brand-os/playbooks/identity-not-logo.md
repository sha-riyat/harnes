# Playbook: identity-not-logo

A mark without pillars and operations is costume.
