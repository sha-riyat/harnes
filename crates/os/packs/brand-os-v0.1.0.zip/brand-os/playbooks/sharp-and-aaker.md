# Playbook: sharp-and-aaker

Keep identity (Aaker/Kapferer) and mental availability (Sharp) in the same review, not in a school fight.
