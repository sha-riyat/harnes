# Example: clinic-assets

Identity pillars: protocol-safe, clinic-native, calm urgency. Assets: named product wordmark, confirmation-bell motif, teal only if unique in local clinic software. Equity hole: salience among practice managers unmeasured. Architecture: branded house, no consumer sub-brand for a feature.
