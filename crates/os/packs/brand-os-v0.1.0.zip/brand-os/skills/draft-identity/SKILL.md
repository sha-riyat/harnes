# Skill: draft-identity

**Purpose:** Draft core and extended identity pillars.

**When to use:** The team only has a mark.

**Steps:**
1. List product, organization, person, symbol views.
2. Separate core vs extended.
3. Check credibility in operations.
4. Bound claims that operations cannot keep.

**Failure modes:**
- Logo packet as identity

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
