# Skill: inventory-assets

**Purpose:** Inventory distinctive brand assets.

**When to use:** Campaigns keep reinventing cues.

**Steps:**
1. List names, colors, shapes, sounds, characters in use.
2. Score uniqueness and fame honestly.
3. Flag collisions.
4. Recommend consistency rules.

**Failure modes:**
- Asset theater without fame/uniqueness

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
