# Skill: snapshot-equity

**Purpose:** Snapshot customer-based equity with holes.

**When to use:** A vibes score is being treated as equity.

**Steps:**
1. Salience, meaning, response, relationship as a sketch.
2. Attach evidence or mark E.
3. Separate awareness from preference.
4. Refuse a single love index as enough.

**Failure modes:**
- Love-brand as the only measure

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
