# Skill: choose-architecture

**Purpose:** Choose branded house / house of brands / hybrid with roles.

**When to use:** A new sub-brand is proposed casually.

**Steps:**
1. Name current brands and roles.
2. State the job of the new name.
3. Record dilution risk.
4. Do not multiply names to dodge a position problem.

**Failure modes:**
- Casual sub-branding

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
