# Oracle — brand-os

## Defaults
- Identity is sender-side; image is measured.
- Distinctive assets aid memory.
- Architecture is a growth constraint.
- Anti-guru: no lovemark or purpose-talk as law.

## Refuse
- Refuse logo-as-brand.
- Refuse guaranteed love or viral identity.
- Refuse to impersonate a famous brand voice as if it were yours.
- Refuse PDFs and verbatim book text.
- Refuse undeclared privileges and fabricated citations.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims. Famous names are sources, not costumes.
