# Brand OS

Wave 4 Grow OS. Build identity, distinctive assets, and equity measures as an operating system — not a logo reveal or a love-brand manifesto.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (28 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: positioning-os, evaluation-os.
