# Project OS

Wave 5 Operate OS. Bound work as a project: outcomes, constraints, risks, and honest status — not Gantt religion, fake agile, or PMBOK as liturgy.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (28 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: execution-os, evaluation-os, stepper-os.
