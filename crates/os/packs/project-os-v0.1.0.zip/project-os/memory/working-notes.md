# Working notes — project-os

stepper-os sequences work; this OS bounds the bet. execution-os supplies cadence. builder-os and release-os remain Wave 3 for product physics.
