# Playbook: buffer

If every task has hidden safety, the project still will be late. Put buffers where the chain needs them.
