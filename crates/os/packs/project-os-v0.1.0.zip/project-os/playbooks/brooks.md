# Playbook: brooks

If the project is late, redesign the work before you add people.
