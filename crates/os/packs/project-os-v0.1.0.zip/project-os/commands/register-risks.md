# Command /register-risks

**Use:** Register risks as managed quantities.
**Invokes:** register-risks
**Input:** charter
**Output artifact type:** register-risks-artifact
**Refuse when:** Risk register as CYA novel
