# Command /status-truth

**Use:** Report status that could change a decision.
**Invokes:** status-truth
**Input:** period
**Output artifact type:** status-truth-artifact
**Refuse when:** Green because we are optimistic
