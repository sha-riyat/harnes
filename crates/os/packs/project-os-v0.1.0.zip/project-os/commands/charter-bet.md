# Command /charter-bet

**Use:** Write a charter a stranger could reject.
**Invokes:** charter-bet
**Input:** intent
**Output artifact type:** charter-bet-artifact
**Refuse when:** Vision-board as charter
