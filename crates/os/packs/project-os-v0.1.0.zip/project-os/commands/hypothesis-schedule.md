# Command /hypothesis-schedule

**Use:** State a schedule as a hypothesis with buffers.
**Invokes:** hypothesis-schedule
**Input:** register
**Output artifact type:** hypothesis-schedule-artifact
**Refuse when:** False-precision Gantt as truth
