# Example: protocol-bet

Charter: three clinics sending protocol-true recall in 8 weeks, kill if legal blocks SMS. Risks: vendor SLA, staff training. Schedule hypothesis: critical chain is the nurse-manager calendar, not engineering. Status: buffer 40 percent burned, ask to drop a fourth clinic.
