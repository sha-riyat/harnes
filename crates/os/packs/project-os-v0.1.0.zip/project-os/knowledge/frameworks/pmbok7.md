# PMBOK 7 principles

Tailor, focus on value, steward uncertainty. Not ITTOs as liturgy.
