# Mythical man-month

Brooks: communication paths and ramp make late projects later.
