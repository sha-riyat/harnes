# Student syndrome

Goldratt: work starts late when every task owns its own safety.
