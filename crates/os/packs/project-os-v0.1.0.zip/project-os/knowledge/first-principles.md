# First principles — project-os

1. Adding people to a late project makes it later (Brooks).
2. Protect the constraint and the buffer; local utilization can destroy the date.
3. Risk is a conversation with options, not a colorful register.
4. A story is a slice of value plus a conversation.
5. Estimates are forecasts, not contracts.
6. Death marches are a management failure, not a culture.
7. Frameworks are options; cargo cult is a failure mode.
8. Certification cram is not a method.
9. No promised date from a novel or a PMBOK slogan.
10. Anti-guru: no Scrum-as-identity; no hero weekend.
