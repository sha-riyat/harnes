# Agent: steward

**Role:** Own doctrine and first-pass artifacts.

**Allowed skills:** charter-bet, register-risks

**Tools:** read-knowledge, emit-artifact. No undeclared network. No secret exfiltration.

**Memory scopes:** working-notes, seed facts.

**Permissions:** read-knowledge, emit-artifact

**Stop conditions:** Oracle refuse match; schema-invalid output; privilege escalation request.

**Evals:** suite.yaml cases for this agent's skills.
