# Skill: hypothesis-schedule

**Purpose:** State a schedule as a hypothesis with buffers.

**When to use:** A Gantt is treated as physics.

**Steps:**
1. Network the work.
2. Name the scarce skill chain.
3. Place buffers honestly.
4. Publish remaining duration, not percent.

**Failure modes:**
- False-precision Gantt as truth

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
