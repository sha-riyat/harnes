# Skill: register-risks

**Purpose:** Register risks as managed quantities.

**When to use:** Risks live in a hallway.

**Steps:**
1. Name uncertainty and impact.
2. Name owner and trigger.
3. Separate student-syndrome and multitasking.
4. No risk poetry.

**Failure modes:**
- Risk register as CYA novel

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
