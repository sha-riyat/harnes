# Skill: status-truth

**Purpose:** Report status that could change a decision.

**When to use:** A green-yellow-red slide is due.

**Steps:**
1. Remaining work and buffer burn.
2. New risks.
3. Ask for a decision or none.
4. Downgrade hope.

**Failure modes:**
- Green because we are optimistic

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
