# Skill: charter-bet

**Purpose:** Write a charter a stranger could reject.

**When to use:** Work is already 'a project' with no outcome.

**Steps:**
1. Name outcome and non-goals.
2. Name constraints of date, budget, quality.
3. Name owner.
4. Name kill criterion.

**Failure modes:**
- Vision-board as charter

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
