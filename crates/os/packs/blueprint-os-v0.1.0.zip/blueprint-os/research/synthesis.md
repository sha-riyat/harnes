# Synthesis — blueprint-os (deepen wave 2-3)

This pack now carries a deepened research layer: 50 ranked real titles and 150 paraphrased practices on the selected top 15 (10 each). Existing bibliographic work was kept and extended; no titles were invented; no PDFs were packaged; GitHub was not cloned.

Practices use the structured extraction schema (insight_id, source, concept, principle, mechanism, when_to_use, when_not, example, confidence A-E). Depth note: structured extraction: existing one-liners preserved as principles where present; remaining selected ranks expanded with book-titled operator moves.

Anti-guru and boundary rules stay in force: educate and organize; verify or omit; no promised outcomes; no fabricated sources. Security-os remains educate/harden only — no exploits, payloads, or access bypass.

Gap note: Academic architecture texts and C4 practice are dense. Public-sector reference architectures in the same popular shelf are thinner. Deepen wave 2-3: 45 ranked titles; 150 structured practices on ranks 1-15 (schema-fill on selected ranks (existing one-liners kept)). Deepen wave 2-3: 50 ranked titles; 150 structured practices on ranks 1-15 (schema-fill on selected ranks (existing one-liners kept)).

Confidence B overall unless a given title is marked A or C-E.
