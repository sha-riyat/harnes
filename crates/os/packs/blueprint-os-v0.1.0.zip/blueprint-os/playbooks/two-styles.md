# Playbook: two-styles

Never brief a style without a rejected alternative and the characteristic it would have won.
