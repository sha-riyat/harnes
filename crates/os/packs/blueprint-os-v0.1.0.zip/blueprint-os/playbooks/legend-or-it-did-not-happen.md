# Playbook: legend-or-it-did-not-happen

Every view ships a legend, a viewpoint, and a date. Mystery clouds are defects.
