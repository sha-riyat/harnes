# Working notes — blueprint-os

Wave 3. Do not treat evaluation-os (Wave 0 harness judges) as architecture evaluation; ATAM-lite lives here. Hand fitness-function automation ideas to quality-evaluation-os and release-os.
