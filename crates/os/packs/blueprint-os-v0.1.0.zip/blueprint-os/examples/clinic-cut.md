# Example: clinic-cut

Context: clinics, SMS gateway, billing. Containers: API, worker, DB. QA: availability of recall send, modifiability of message templates. Trade: modular monolith first; split worker if send latency and deploy cadence actually hurt. ADR records the rejected early-microservices option.
