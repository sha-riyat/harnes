# Skill: draw-c4

**Purpose:** Produce C4-style context, container, and component notes.

**When to use:** Stakeholders cannot point at the running pieces.

**Steps:**
1. Name people and systems at context.
2. Name deployable containers.
3. Name significant components.
4. Add a legend and a non-goal.

**Failure modes:**
- Boxes without relations

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
