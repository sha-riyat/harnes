# Skill: map-quality-attributes

**Purpose:** Map quality attributes to tactics and scenarios.

**When to use:** Non-functionals are unnamed or slogan-like.

**Steps:**
1. List attributes that matter here.
2. Write a scenario for each.
3. Map tactics.
4. Flag conflicts.

**Failure modes:**
- Unmeasurable attributes

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
