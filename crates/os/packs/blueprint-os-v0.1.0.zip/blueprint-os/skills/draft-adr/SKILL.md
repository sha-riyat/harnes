# Skill: draft-adr

**Purpose:** Draft or critique an architecture decision record.

**When to use:** A significant structural choice is pending.

**Steps:**
1. State context and forces.
2. Name options with discarded ones.
3. Link to quality attributes.
4. Record follow-up risks.

**Failure modes:**
- Decision without alternatives

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
