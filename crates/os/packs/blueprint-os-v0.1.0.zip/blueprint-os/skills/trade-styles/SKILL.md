# Skill: trade-styles

**Purpose:** Compare architecture styles against characteristics.

**When to use:** A style is being copied from fashion.

**Steps:**
1. Name the characteristics that must win.
2. Score two or more styles.
3. Call the spend (what you give up).
4. Recommend with a kill condition.

**Failure modes:**
- Single-style advocacy

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
