# Quality-attribute tactics

Each attribute has a small catalog of tactics (replicate, checkpoint, abstract, limit). Pick, do not invent adjectives.
