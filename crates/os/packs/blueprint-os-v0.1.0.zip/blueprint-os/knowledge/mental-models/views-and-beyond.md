# Views and beyond

Module, C&C, allocation. Plus decision log. One drawing is not the architecture.
