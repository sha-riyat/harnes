# First principles — blueprint-os

1. Architecture is structures for reasoning about quality attributes.
2. Name attributes and tactics, not logos.
3. Views need viewpoints and legends.
4. Evaluate with scenarios before locking a style.
5. Modular monolith and microservices are alternatives, not ranks.
6. Team structure and architecture couple (and can be designed).
7. Evolution and governance beat a once-drawn cathedral.
8. A framework is not an architecture.
9. No promised scale from a pattern language.
10. Anti-guru: no conference-style cargo cult.
