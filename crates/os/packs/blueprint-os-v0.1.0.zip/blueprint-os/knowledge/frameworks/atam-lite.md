# ATAM-lite

Scenarios, utility tree, sensitivity and trade-off points. Full ATAM is a workshop, not a chatbot.
