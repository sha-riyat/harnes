# Blueprint OS

Wave 3 Build OS. Turn quality-attribute goals into viewed architecture: decisions, C4-style maps, and explicit style trade-offs — not poster diagrams.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (32 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: research-os, evaluation-os.
