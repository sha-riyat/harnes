# Command /adr

**Use:** Draft an architecture decision record.
**Invokes:** draft-adr
**Input:** decision context
**Output artifact type:** adr
**Refuse when:** no quality-attribute link
