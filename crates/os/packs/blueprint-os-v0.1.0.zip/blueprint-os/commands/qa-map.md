# Command /qa-map

**Use:** Map quality attributes to tactics.
**Invokes:** map-quality-attributes
**Input:** system + attributes
**Output artifact type:** qa-map
**Refuse when:** slogan attributes
