# Command /trade

**Use:** Compare two styles.
**Invokes:** trade-styles
**Input:** styles + constraints
**Output artifact type:** style-trade
**Refuse when:** one-true-way
