Phase 0 agent-os.
