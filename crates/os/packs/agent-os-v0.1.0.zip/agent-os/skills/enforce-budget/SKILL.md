    # Skill: enforce-budget

    **Purpose:** Consume a step and stop if exhausted.

    **When to use:** Every agent loop iteration.

    **Steps:**
    1. Read remaining.
2. Decrement or refuse.
3. Emit status.
4. Trigger handoff on zero if work remains.

    **Failure modes:**
    - Negative budget

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
