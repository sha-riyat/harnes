    # Skill: specify-agent

    **Purpose:** Create an agent spec matching core/schemas/agent.schema.json.

    **When to use:** New agent.

    **Steps:**
    1. Name id and role.
2. List skills and tools.
3. List memory scopes and permissions.
4. Write abort conditions and budget.

    **Failure modes:**
    - Empty abort
- God-mode permissions

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
