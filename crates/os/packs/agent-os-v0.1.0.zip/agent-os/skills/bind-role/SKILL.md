    # Skill: bind-role

    **Purpose:** Bind the spec to existing skills and tool contracts.

    **When to use:** Spec drafted.

    **Steps:**
    1. Verify skills exist.
2. Map tools to contracts.
3. Intersect permissions.
4. Emit binding.

    **Failure modes:**
    - Unknown skill id

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
