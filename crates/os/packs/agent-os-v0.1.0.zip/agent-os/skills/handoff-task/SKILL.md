    # Skill: handoff-task

    **Purpose:** Transfer a typed artifact to another agent or human.

    **When to use:** Stop, escalate, or split work.

    **Steps:**
    1. Validate artifact.
2. Name receiver.
3. State why.
4. Close or pause sender budget.

    **Failure modes:**
    - Chat paste as handoff

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
