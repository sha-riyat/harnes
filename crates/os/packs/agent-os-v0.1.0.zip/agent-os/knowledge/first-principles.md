# First principles — agent-os

1. An agent has goals, beliefs, and actions under a protocol (Wooldridge).
2. A chat wrapper is not a multi-agent system.
3. Handoffs, stop rules, and evals are the runtime.
4. Alignment and authorization bound autonomy (Russell).
5. Team and software topologies still apply (Skelton/Pais).
6. No access bypass via tool use.
7. No promised AGI workforce.
8. Humans remain accountable for side effects.
9. Critique of hype is literacy.
10. Anti-guru: no swarm-slide; no agent-army merch.
