# MAS building blocks

Wooldridge: agents, environments, protocols, preferences, coalitions. Map to OS agents, adapters, workflows, evals.
