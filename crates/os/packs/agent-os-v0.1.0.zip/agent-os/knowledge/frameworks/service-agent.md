# Agent as service

API, memory scope, health, tools, traces. If it cannot be described as a service, it is a prompt.
