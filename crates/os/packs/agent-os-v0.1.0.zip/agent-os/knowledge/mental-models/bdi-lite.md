# Beliefs, desires, intentions (lite)

Beliefs from memory, desires from goals, intentions from committed workflows. Useful as a checklist, not a religion.
