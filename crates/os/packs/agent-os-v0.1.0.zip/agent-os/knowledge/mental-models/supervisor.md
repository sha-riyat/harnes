# Supervisor pattern

A supervisor assigns, budgets, and stops workers. It does not do their skills unless handoff says so.
