# Example: critic-handoff

Doer budget exhausted mid-synthesis. enforce-budget stop=true. handoff-task to critic with partial artifact and why=budget.
