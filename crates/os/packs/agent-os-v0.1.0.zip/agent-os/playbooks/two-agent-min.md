# Playbook: two-agent-min

Prefer a doer and a critic over one agent with both hats when the artifact is consequential (eval gate, promotion, release).
