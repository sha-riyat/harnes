# Playbook: stop-list

Copy abort conditions into evals as refuse cases.
