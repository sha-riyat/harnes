# mcp adapter — agent-os

Purpose of this OS: Define agent lifecycle, roles, bounds, budgets, handoff, and stop conditions so agents are services, not personalities.

## Mapping
Expose each skill as an MCP tool with input.schema.json. Resources expose knowledge/*.yaml and evals/suite.yaml. Prompts expose playbooks.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Does not ship a running MCP server binary; this is the contract.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
