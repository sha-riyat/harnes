# Command /budget

**Use:** Check or consume budget.
**Invokes:** enforce-budget
**Input:** agent id
**Output artifact type:** budget-status
**Refuse when:** continue at 0
