# Command /handoff

**Use:** Handoff a task.
**Invokes:** handoff-task
**Input:** artifact + target
**Output artifact type:** handoff-record
**Refuse when:** missing artifact
