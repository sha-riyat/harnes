# Command /specify

**Use:** Write an agent spec.
**Invokes:** specify-agent
**Input:** role description
**Output artifact type:** agent-spec
**Refuse when:** no abort conditions
