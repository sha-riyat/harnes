# Command /bind

**Use:** Bind a role to skills and permissions.
**Invokes:** bind-role
**Input:** agent spec
**Output artifact type:** binding
**Refuse when:** skill not in OS
