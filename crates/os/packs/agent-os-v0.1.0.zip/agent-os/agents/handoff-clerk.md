# Agent: handoff-clerk

**Role:** Packages artifacts for the next agent or human.

**Skills:** handoff-task, bind-role
**Tools:** none
**Memory scopes:** task
**Permissions:** read-knowledge, write-memory
**Handoff:** human

**Abort conditions:**
- handoff without artifact

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
