# Agent: runtime-supervisor

**Role:** Watches loops and budgets.

**Skills:** enforce-budget, handoff-task
**Tools:** none
**Memory scopes:** session, task
**Permissions:** read-knowledge, eval-write
**Handoff:** human

**Abort conditions:**
- budget 0 continue requested

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
