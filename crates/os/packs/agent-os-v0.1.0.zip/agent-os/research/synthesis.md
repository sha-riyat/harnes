# Synthesis — agent-os (deepen wave 6-7-AI)

This pack now carries a deepened research layer: 41 ranked real titles and 150 paraphrased practices on the selected top 15 (10 each). Existing bibliographic work was kept and extended; no titles were invented; no PDFs were packaged; GitHub was not cloned.

Practices use the structured extraction schema (insight_id, source, concept, principle, mechanism, when_to_use, when_not, example, confidence A-E). Depth note: structured extraction: existing one-liners preserved as principles where present; remaining selected ranks expanded with book-titled operator moves (schema-fill).

Anti-guru and money/capital/board boundaries stay in force: educate and organize; verify or omit; no personalized advice-as-fact; no promised IRR, returns, synergies, or closes; not a broker, counsel, or audit opinion. Automation and agent rows refuse exploits and access bypass.

Gap note: Honest verified titles only; residual gaps stay published. Deepen wave 6-7-AI: 41 ranked titles; 150 structured practices on ranks 1-15 (schema-fill on selected ranks (existing one-liners kept)).

Confidence B overall unless a given title is marked A or C-E.
