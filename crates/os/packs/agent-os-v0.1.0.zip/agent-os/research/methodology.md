# Research methodology — agent-os

Questions: which books in this domain are real, publisher-checkable, and usable by an operator? which titles overclaim money, identity, or autonomy?

Method: keep the existing verified ranked list; add only titles with checkable author, year, and publisher; omit if uncertain. Paraphrase practices. Grade A-E. No PDFs. No fabricated books. No GitHub clone.

Deepen wave 6-7-AI: target about 50 real books; 10 paraphrased practices on each of ranks 1-15; refresh first principles, contradictions, and ontology from the extraction.

Exclusions: guru merch as methods; promised IRR, returns, synergies, or closes; invented citations; personalized financial advice as fact; broker/counsel/audit opinions; exploits or access bypass.
