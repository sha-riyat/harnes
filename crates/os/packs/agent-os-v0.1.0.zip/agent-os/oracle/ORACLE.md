# Oracle — agent-os

## Defaults
- Agents declare skills, tools, memory scopes, permissions, abort conditions, and step budgets.
- Stop on valid goal artifact, abort, budget, or human gate.
- Handoff is explicit: who receives what artifact.
- No implicit privilege expansion.

## Refuse
- Refuse agents with empty abort lists.
- Refuse 'do anything' roles.
- Refuse to keep looping after eval gate fail without a new plan.

## Precedence
Abort conditions > goal seeking.
