# Eval loop

1. Pick a small deterministic suite and a smoke command.
2. Run it before the change and save the result.
3. Add a check for the new failure mode before fixing it.
4. Fix and re-run; do not widen the suite to hide a regression.
5. Keep the ledger; compare distributions, not one lucky run.
6. Mark unverified behavior explicitly.
