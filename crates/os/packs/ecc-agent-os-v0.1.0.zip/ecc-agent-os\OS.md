# ECC Agent OS

## Purpose
Build and operate agent harnesses with evidence: bounded loops, explicit budgets, evaluation before tuning, handoffs, prompt caching and orchestration.

## Runtime loop
1. Define the observable outcome and the eval that proves it.
2. Bound the loop: max rounds, wall clock, tokens and cost.
3. Give each agent a role, context, tools and a stop condition.
4. Run the eval before changing the harness; keep a baseline.
5. Change one component at a time; compare on the same suite.
6. Record the result and the decision; promote only reviewed memory.

## Refuse
Unbounded autonomy, hidden spend, self-approval, benchmark claims without a baseline, or a harness change that was not evaluated.

## Skills
- agent-eval: skills/agent-eval/SKILL.md
- eval-harness: skills/eval-harness/SKILL.md
- agent-harness-construction: skills/agent-harness-construction/SKILL.md
- agent-introspection-debugging: skills/agent-introspection-debugging/SKILL.md
- agent-self-evaluation: skills/agent-self-evaluation/SKILL.md
- autonomous-agent-harness: skills/autonomous-agent-harness/SKILL.md
- autonomous-loops: skills/autonomous-loops/SKILL.md
- continuous-agent-loop: skills/continuous-agent-loop/SKILL.md
- team-agent-orchestration: skills/team-agent-orchestration/SKILL.md
- plan-orchestrate: skills/plan-orchestrate/SKILL.md
- parallel-execution-optimizer: skills/parallel-execution-optimizer/SKILL.md
- prompt-optimizer: skills/prompt-optimizer/SKILL.md
- prompt-caching-strategy: skills/prompt-caching-strategy/SKILL.md
- cost-aware-llm-pipeline: skills/cost-aware-llm-pipeline/SKILL.md
- cost-tracking: skills/cost-tracking/SKILL.md
- context-budget: skills/context-budget/SKILL.md
- token-budget-advisor: skills/token-budget-advisor/SKILL.md
- skill-comply: skills/skill-comply/SKILL.md
- skill-scout: skills/skill-scout/SKILL.md
- mcp-server-patterns: skills/mcp-server-patterns/SKILL.md
- search-first: skills/search-first/SKILL.md
- documentation-lookup: skills/documentation-lookup/SKILL.md
- deep-research: skills/deep-research/SKILL.md

## Load contract
Load manifest.yaml, bind oracle/ORACLE.md, route via routing/intents.yaml, execute skills/workflows, emit typed artifacts, and keep evidence for every claim.

## Evidence
A command result, a file:line reference, an eval check, or a telemetry event is evidence. A feeling is not. If a check was not run, say so.

## Provenance
Source: https://github.com/affaan-m/ECC (MIT), pinned at 90606c8315ee09cafc303515c5f33024db6b9882.
The skills/ trees are copied verbatim from ECC. OS.md, oracle/, playbooks/, rules/, NOTICE and PROVENANCE.md are harnes wrappers. See LICENSE-ECC.
