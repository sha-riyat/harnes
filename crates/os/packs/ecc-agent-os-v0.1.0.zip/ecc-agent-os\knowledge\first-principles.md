# First principles

- Evidence beats confidence.
- The smallest change that proves the behavior.
- Stop conditions are part of the design.
- A human owns irreversible actions.
- Attribution and provenance are part of correctness.
