# Harness engineer

Load agent-harness-construction, context-budget and agent-eval. Bound loops, measure cost, and compare changes on the same suite.
