# Cost incident

1. Stop the loop or lower the budget; preserve the partial report.
2. Find the expensive path: retries, oversized context, cache misses, redundant reviewers.
3. Reduce one cause at a time: context, rounds, model, parallelism.
4. Re-run the eval to prove quality did not collapse.
5. Record the spend, the cause and the new bound.
