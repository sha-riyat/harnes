# Provenance

- Source: https://github.com/affaan-m/ECC
- License: MIT (see LICENSE-ECC)
- Pinned commit: 90606c8315ee09cafc303515c5f33024db6b9882
- Upstream author: Affaan Mustafa
- Selection: 23 skills, curated for harnes; not the full ECC catalogue.

## Copied verbatim
- skills/agent-eval/
- skills/eval-harness/
- skills/agent-harness-construction/
- skills/agent-introspection-debugging/
- skills/agent-self-evaluation/
- skills/autonomous-agent-harness/
- skills/autonomous-loops/
- skills/continuous-agent-loop/
- skills/team-agent-orchestration/
- skills/plan-orchestrate/
- skills/parallel-execution-optimizer/
- skills/prompt-optimizer/
- skills/prompt-caching-strategy/
- skills/cost-aware-llm-pipeline/
- skills/cost-tracking/
- skills/context-budget/
- skills/token-budget-advisor/
- skills/skill-comply/
- skills/skill-scout/
- skills/mcp-server-patterns/
- skills/search-first/
- skills/documentation-lookup/
- skills/deep-research/

## harnes wrappers

manifest.yaml, OS.md, oracle/ORACLE.md, routing/intents.yaml, playbooks/, rules/, agents/, NOTICE and this file were written for harnes. They do not modify the copied skills.
