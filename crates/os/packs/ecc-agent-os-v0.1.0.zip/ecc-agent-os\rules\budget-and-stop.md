# Budget and stop

Every autonomous loop has a hard stop and a spend ceiling. A loop that cannot state its stop condition does not run. On cancel, preserve the worktree and the report.
