# Handoff

A handoff states the goal, the completed work, the exact next action, the changed files, the checks already run and the open questions. It never claims work that is not in the files or events.
