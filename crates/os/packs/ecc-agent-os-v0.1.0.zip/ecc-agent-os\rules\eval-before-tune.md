# Evaluate before tuning

No harness change is promoted without a baseline and a comparison on the same suite. One component at a time. Record the eval path and the result.
