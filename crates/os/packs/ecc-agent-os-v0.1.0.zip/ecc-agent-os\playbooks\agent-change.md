# Change an agent harness

1. State the failure or capability gap and the observable outcome.
2. Capture a baseline on the existing eval suite.
3. Change one component: context, prompt, tool, model, loop or review.
4. Re-run the same suite; compare pass rate, cost and latency.
5. Keep the change only if it wins or is neutral and simpler.
6. Record the result, the trade-off and the rollback.
