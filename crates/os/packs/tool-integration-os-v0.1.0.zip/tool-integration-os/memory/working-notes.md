Phase 0. No live API keys stored.
