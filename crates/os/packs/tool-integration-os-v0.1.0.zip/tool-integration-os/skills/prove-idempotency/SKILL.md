    # Skill: prove-idempotency

    **Purpose:** State how a side-effecting tool can be safely retried.

    **When to use:** Tool has side effects.

    **Steps:**
    1. Choose key strategy.
2. Define replay behavior.
3. If impossible, require saga compensation.
4. Record in contract.

    **Failure modes:**
    - Money movement with shrug

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
