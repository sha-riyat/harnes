    # Skill: map-adapter

    **Purpose:** Map a contract onto a host adapter.

    **When to use:** Contract exists.

    **Steps:**
    1. Read host capabilities.
2. Mark supported vs stub.
3. Map auth to permission.
4. Document gaps.

    **Failure modes:**
    - Pretend support

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
