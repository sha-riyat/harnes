    # Skill: isolate-failure

    **Purpose:** Classify failure and choose retry, compensate, or abort.

    **When to use:** Tool returned error or timeout.

    **Steps:**
    1. Map to taxonomy timeout/auth/invalid/unavailable/unsafe.
2. Choose retry policy.
3. Open a failure-record.
4. Never retry unsafe.

    **Failure modes:**
    - Unknown mapped to retry forever

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
