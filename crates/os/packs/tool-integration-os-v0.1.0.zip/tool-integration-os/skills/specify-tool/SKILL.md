    # Skill: specify-tool

    **Purpose:** Create a tool contract with schema, permission, timeout, and failures.

    **When to use:** New tool or wrapping an API.

    **Steps:**
    1. Name the tool.
2. Write input/output schemas.
3. Bind permission.
4. List failure codes and timeout.

    **Failure modes:**
    - Missing timeout
- Open-ended shell tool without allowlist

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
