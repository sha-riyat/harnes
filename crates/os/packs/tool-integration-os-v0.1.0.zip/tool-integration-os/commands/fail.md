# Command /fail

**Use:** Classify a tool failure.
**Invokes:** isolate-failure
**Input:** error
**Output artifact type:** failure-record
**Refuse when:** empty error
