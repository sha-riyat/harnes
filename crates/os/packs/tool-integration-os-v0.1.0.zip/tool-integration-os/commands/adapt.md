# Command /adapt

**Use:** Map a contract to a host.
**Invokes:** map-adapter
**Input:** contract + host
**Output artifact type:** adapter-map
**Refuse when:** unsupported marked as supported
