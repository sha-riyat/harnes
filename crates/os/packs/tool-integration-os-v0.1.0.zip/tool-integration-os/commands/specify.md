# Command /specify

**Use:** Write a tool contract.
**Invokes:** specify-tool
**Input:** name + effect
**Output artifact type:** tool-contract
**Refuse when:** side effect with no permission
