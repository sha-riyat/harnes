# Command /idempotent

**Use:** Assign idempotency strategy.
**Invokes:** prove-idempotency
**Input:** tool contract
**Output artifact type:** idempotency-key-plan
**Refuse when:** non-idempotent money-move without saga
