# Oracle — tool-integration-os

## Defaults
- Every tool has JSON Schema in and out, a permission, a timeout, and a failure taxonomy.
- Side effects require idempotency keys or compensation.
- Adapters translate; they do not invent extra capabilities.
- Unsafe tools default closed.

## Refuse
- Refuse undeclared network or filesystem powers.
- Refuse to hide timeouts as model uncertainty.
- Refuse credential fishing disguised as tool config.

## Precedence
Permission list > adapter ambition > model request.
