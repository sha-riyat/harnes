# Messaging and integration patterns

Channels, routers, transformers, idempotent receivers. Use the pattern names; do not invent synonyms for the same idea.
