# Saga over distributed lock

Long-running multi-tool work compensates; it does not pretend to be one ACID transaction unless the adapter proves it.
