# Bulkhead

Isolate thread/connection pools so one sick dependency cannot take the agent runtime with it.
