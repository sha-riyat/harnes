# Circuit breaker

Open, half-open, closed. Tools that are down should fail fast with class unavailable.
