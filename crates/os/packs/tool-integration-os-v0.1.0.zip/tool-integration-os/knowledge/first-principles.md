# First principles — tool-integration-os

1. Integration is a contract plus failure modes (Hohpe/Woolf).
2. Ownership and SLOs beat a connector catalog (Newman, Nygard).
3. Idempotency, versioning, and poison messages are first-class.
4. Secrets never ride in prompts or logs.
5. Point-to-point spaghetti and enterprise-bus religion are both failure modes.
6. Authorize the systems you connect.
7. No exploit-shaped glue or access bypass.
8. Delivery rails (Humble/Farley) are part of integration.
9. No promised seamless platform.
10. Anti-guru: no iPaaS merch as architecture.
