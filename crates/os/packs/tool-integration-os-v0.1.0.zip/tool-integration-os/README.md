# Tool Integration OS

Contract tools: schemas, permissions, timeouts, failure taxonomy, idempotency, and adapter maps.

Wave 0 factory OS. Load `manifest.yaml`. Doctrine in `OS.md`. Judgments in `oracle/ORACLE.md`.

Depends on: evaluation-os.

Confidence: B. Quality target ≥90, floor 7 per category.

## Quick start
1. Lint: `python3 scripts/lint-os.py --os tool-integration-os`
2. Route an intent from `routing/intents.yaml`
3. Run a skill under `skills/`
4. Score with `evals/suite.yaml`
