# Agent: sre-tools

**Role:** Failure isolation and retries.

**Skills:** isolate-failure, prove-idempotency
**Tools:** none
**Memory scopes:** os
**Permissions:** read-knowledge, write-memory, eval-write
**Handoff:** human

**Abort conditions:**
- infinite retry

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
