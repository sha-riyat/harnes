# Agent: contract-writer

**Role:** Authors tool contracts.

**Skills:** specify-tool, map-adapter, isolate-failure, prove-idempotency
**Tools:** none
**Memory scopes:** os, task
**Permissions:** read-knowledge, write-memory
**Handoff:** adapter-engineer

**Abort conditions:**
- tool with no permission named

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
