# Example: wrap-search

specify-tool for web-search with permission network, timeout 15s, failures timeout/unavailable. map-adapter onto generic-llm function calling. prove-idempotency: GET-like search is naturally retry-safe.
