# Playbook: least-privilege

Each tool lists one primary permission. Broader tools are split.
