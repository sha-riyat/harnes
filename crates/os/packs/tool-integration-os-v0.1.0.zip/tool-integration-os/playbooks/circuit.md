# Playbook: circuit

After N failures of class unavailable, open a circuit: fail fast, emit failure-record, do not hammer the dependency (Release It! spirit).
