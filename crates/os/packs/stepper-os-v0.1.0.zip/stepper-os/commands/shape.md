# Command /shape

**Use:** Shape a bet.
**Invokes:** shape-bet
**Input:** problem + appetite
**Output artifact type:** shaped-bet
**Refuse when:** unshaped wish
