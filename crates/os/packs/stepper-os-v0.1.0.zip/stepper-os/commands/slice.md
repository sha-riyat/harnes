# Command /slice

**Use:** Cut a thin slice.
**Invokes:** slice-thin
**Input:** map
**Output artifact type:** thin-slice
**Refuse when:** layer cake
