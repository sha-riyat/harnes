# Command /seq

**Use:** Sequence releases.
**Invokes:** sequence-releases
**Input:** slices + delay costs
**Output artifact type:** release-sequence
**Refuse when:** no kill rule
