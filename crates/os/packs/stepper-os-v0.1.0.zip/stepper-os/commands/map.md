# Command /map

**Use:** Build a story map.
**Invokes:** story-map
**Input:** journey
**Output artifact type:** story-map
**Refuse when:** feature pile
