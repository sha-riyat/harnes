# Working notes — stepper-os

Name is stepping, not Circle. Hand construction to builder-os and path-to-prod to release-os.
