# Stepper OS

Wave 3 Build OS. Sequence valuable thin slices — maps, splits, shaped bets, release steps — so work walks instead of circling.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (32 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: research-os, evaluation-os.
