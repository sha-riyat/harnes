# Skill: sequence-releases

**Purpose:** Order slices by cost of delay and risk.

**When to use:** Everything is P0.

**Steps:**
1. Estimate cost of delay qualitatively.
2. Watch queues.
3. Place a walking skeleton first.
4. Attach a stop rule.

**Failure modes:**
- No stop rule

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
