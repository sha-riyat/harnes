# Skill: shape-bet

**Purpose:** Shape a time-boxed bet.

**When to use:** Work is about to enter a cycle unshaped.

**Steps:**
1. State problem and appetite.
2. Fat-marker solution.
3. List rabbit holes and no-gos.
4. Write the pitch as a bet, not a backlog forever.

**Failure modes:**
- Wish with a date

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
