# Skill: story-map

**Purpose:** Map activities and tasks left to right.

**When to use:** The backlog lost the plot.

**Steps:**
1. Name the user and the journey.
2. Lay activities left to right.
3. Fill tasks under each.
4. Mark already-true vs missing.

**Failure modes:**
- Feature inventory posing as a map

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
