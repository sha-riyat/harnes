# Skill: slice-thin

**Purpose:** Cut an end-to-end walking skeleton.

**When to use:** A slice is becoming a platform layer.

**Steps:**
1. Pick a user-visible outcome.
2. Walk every activity with the thinnest task.
3. List what is out of the slice.
4. Name a demo that a user would recognize.

**Failure modes:**
- Horizontal layer cake

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
