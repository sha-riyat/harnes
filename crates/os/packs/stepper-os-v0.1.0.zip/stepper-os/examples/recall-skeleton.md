# Example: recall-skeleton

Map: find patient, pick slot, send, confirm. First slice: one patient, one template, one SMS, one confirmation screen. Out of scope: campaigns, analytics, role admin. Appetite: two weeks. Stop if carrier integration is the rabbit hole — fake send log instead.
