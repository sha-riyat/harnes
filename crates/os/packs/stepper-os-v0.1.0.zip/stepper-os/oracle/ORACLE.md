# Oracle — stepper-os

## Defaults
- Left-to-right journey, then down into slices.
- Thin end-to-end beats thick layers.
- Appetite is a budget.
- Queues and cost of delay sequence work.

## Refuse
- Refuse infinite backlogs as a plan.
- Refuse CRUD splits that do not walk a user journey.
- Refuse PDFs and verbatim book text.
- Refuse velocity promises.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims.
