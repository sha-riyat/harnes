# Playbook: walking-skeleton

First release does one real user job poorly-but-completely, not all jobs' databases.
