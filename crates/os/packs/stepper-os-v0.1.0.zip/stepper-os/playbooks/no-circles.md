# Playbook: no-circles

Status meetings that do not change the next slice are circles. Stop them.
