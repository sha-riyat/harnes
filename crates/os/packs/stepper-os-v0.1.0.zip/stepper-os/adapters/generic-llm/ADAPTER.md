# generic-llm adapter — stepper-os

Purpose of this OS: Sequence valuable thin slices — maps, splits, shaped bets, release steps — so work walks instead of circling.

## Mapping
Pack SKILL.md + schemas + oracle excerpts into a single system block. Tools via JSON function-calling if the host supports it; otherwise ask the model to emit typed JSON matching output.schema.json.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Stub contract only. Not a live client. No copyrighted book ingest.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
