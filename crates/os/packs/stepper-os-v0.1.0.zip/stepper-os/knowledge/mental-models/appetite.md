# Appetite

Time is fixed; scope flexes. Unshaped work does not enter the cycle.
