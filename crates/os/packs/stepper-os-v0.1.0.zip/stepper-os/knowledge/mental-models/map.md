# Story map

Activities on the backbone; tasks hanging; slices as horizontal cuts.
