# INVEST hygiene

Cohn-school check, not a religion.
