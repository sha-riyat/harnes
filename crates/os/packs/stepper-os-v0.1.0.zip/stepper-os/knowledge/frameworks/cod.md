# Cost of delay

Sequence by economic delay, not by shout volume.
