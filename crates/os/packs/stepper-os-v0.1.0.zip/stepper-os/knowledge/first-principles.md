# First principles — stepper-os

1. A story is a placeholder for a conversation plus a slice of value.
2. Maps show the whole so a thin slice can be chosen.
3. Flow, WIP, and cost of delay beat utilization theater.
4. Estimates are forecasts, not contracts.
5. Retrospectives step the process.
6. Frameworks are options; cargo cult is a failure mode.
7. Risk is a step, not a register leftover.
8. Shape work to an appetite when that is the local method.
9. No promised 2x output from a ceremony.
10. Anti-guru: no Scrum-as-identity.
