# Command /appraise

**Use:** Appraise a study.
**Invokes:** appraise-study
**Input:** report
**Output artifact type:** finding-memo
**Refuse when:** chart with no method
