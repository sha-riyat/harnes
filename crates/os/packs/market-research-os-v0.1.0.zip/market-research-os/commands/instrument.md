# Command /instrument

**Use:** Review instrument.
**Invokes:** review-instrument
**Input:** draft
**Output artifact type:** instrument-review
**Refuse when:** copyrighted item dump
