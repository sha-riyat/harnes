# Command /design

**Use:** Choose design and tool.
**Invokes:** choose-design
**Input:** brief
**Output artifact type:** design-choice
**Refuse when:** survey-by-default on why
