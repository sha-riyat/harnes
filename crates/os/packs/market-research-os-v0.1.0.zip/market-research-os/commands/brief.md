# Command /brief

**Use:** Write research brief.
**Invokes:** write-brief
**Input:** decision
**Output artifact type:** research-brief
**Refuse when:** decoration research
