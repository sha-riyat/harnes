# Market Research OS

Turn a management decision into a designed study with honest error, not a dashboard in search of a question.

Wave 2 Discover and Decide OS. Load `manifest.yaml`. Doctrine in `OS.md`. Judgments in `oracle/ORACLE.md`.

Depends on: research-os, librarian-os, evaluation-os.

Confidence: A. Quality target ≥90, floor 7 per category.

## Quick start
1. Lint: `python3 scripts/lint-os.py --os market-research-os`
2. Route an intent from `routing/intents.yaml`
3. Run a skill under `skills/`
4. Score with `evals/suite.yaml`
