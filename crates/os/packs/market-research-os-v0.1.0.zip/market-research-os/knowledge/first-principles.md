# First principles — market-research-os

1. The question and the frame come before the instrument.
2. A sample is not the population. Name the frame.
3. Questions measure what they measure, including bias.
4. Qualitative and quantitative answer different claims.
5. Charts are arguments; integrity first.
6. Behavioral residue is not a mind-read.
7. Ethics: consent, no dark-pattern research.
8. How Brands Grow and Jobs-to-be-Done can conflict; pair them.
9. No guaranteed segment.
10. Anti-guru: no neuromarketing theater.
