# Six-step process

Problem, approach, design, field, analysis, report — skip none.
