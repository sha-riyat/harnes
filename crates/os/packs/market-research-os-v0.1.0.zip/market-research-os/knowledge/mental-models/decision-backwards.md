# Decision backwards

Write the choice and the threshold that would change it, then design.
