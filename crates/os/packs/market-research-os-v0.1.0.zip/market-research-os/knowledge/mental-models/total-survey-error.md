# Total survey error

Coverage, sampling, nonresponse, measurement. Fix the largest, not the fanciest.
