# Example: smb-churn

Decision: keep or kill onboarding v2. Brief: why churn after month 2 in SMBs. Design: 12 interviews plus product logs, then a descriptive tracker. Instrument: past-behavior questions, no hypothetical praise. Appraise any vendor NPS add-on as insufficient for why.
