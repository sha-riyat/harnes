# Playbook: why-not-survey

Why questions start qualitative or observational. Surveys estimate prevalence after constructs exist.
