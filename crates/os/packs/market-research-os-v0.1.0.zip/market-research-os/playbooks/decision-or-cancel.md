# Playbook: decision-or-cancel

If no decision would change, cancel. Research theater burns trust and budget.
