# Agent: instrument-editor

**Role:** Reviews questions, scales, and samples.

**Skills:** write-brief, choose-design
**Tools:** none
**Memory scopes:** task
**Permissions:** read-knowledge
**Handoff:** research-designer

**Abort conditions:**
- fabricated fieldwork

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
