    # Skill: choose-design

    **Purpose:** Choose exploratory, descriptive, or causal design and a tool.

    **When to use:** A brief exists.

    **Steps:**
    1. Match question to design.
2. Pick tool (interview, ethnography, survey, experiment, secondary).
3. State sampling approach.
4. State ethics constraints.

    **Failure modes:**
    - Defaulting to a survey for a why question

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
