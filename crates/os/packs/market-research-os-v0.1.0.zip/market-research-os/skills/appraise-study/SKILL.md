    # Skill: appraise-study

    **Purpose:** Appraise a vendor or internal study.

    **When to use:** A report arrived.

    **Steps:**
    1. Check sample, incentive, response, and items.
2. Separate statistical from managerial significance.
3. List limitations.
4. Grade confidence A-E.

    **Failure modes:**
    - Accepting a chart with no method

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
