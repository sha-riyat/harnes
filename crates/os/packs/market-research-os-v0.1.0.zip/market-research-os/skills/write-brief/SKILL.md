    # Skill: write-brief

    **Purpose:** Translate a decision into a research brief.

    **When to use:** A manager wants research.

    **Steps:**
    1. State the decision that would change.
2. Write the research questions.
3. Note population.
4. List already-known secondary data.
5. Stop if no decision would change.

    **Failure modes:**
    - Research as decoration

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
