    # Skill: review-instrument

    **Purpose:** Review a questionnaire or discussion guide.

    **When to use:** An instrument draft exists.

    **Steps:**
    1. Flag leading, double-barreled, and hypothetical items.
2. Check construct vs question.
3. Check order effects.
4. Require a pretest plan.

    **Failure modes:**
    - Pasting copyrighted scale items verbatim into the OS

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
