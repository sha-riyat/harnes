# hermes adapter — market-research-os

Purpose of this OS: Turn a management decision into a designed study with honest error, not a dashboard in search of a question.

## Mapping
Prefer strict JSON mode. Hermes tool-call envelopes wrap tool-integration-os contracts. Keep oracle refuse rules in the preamble.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Does not define Hermes GGUF files or sampler settings.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
