# Synthesis — decision-os (deepen wave 1)

This pack now carries a deepened research layer: 70 ranked real titles and 150 paraphrased practices on the selected top 15 (10 each). Existing bibliographic work was kept and extended; no titles were invented.

Practices use the structured extraction schema (insight_id, source, concept, principle, mechanism, when_to_use, when_not, example, confidence A-E). One-line practices on earlier selected ranks were preserved as principles and expanded; remaining top-15 ranks received full paraphrases.

Anti-guru and boundary rules stay in force: educate and organize; no medical, legal, or personalized financial advice as fact; no promised outcomes; no celebrity impersonation; no verbatim book text; no PDFs.

Gap note: Target 50 reached in book form after web-verifying listings (publisher, Open Library, WorldCat, ISBN catalog, or DOI). Remaining gap is paper-heavy (IARPA ACE / Good Judgment scoring papers; applied MAUT cases) and thinner dedicated DA books for irreversible personal choices (marriage, migration, fertility) than for managerial choice. Motivational decisiveness manuals exist; they are refused as doctrine. Deepen wave 1: 70 ranked titles; 150 structured practices on ranks 1-15. Deepen wave 1: 70 ranked titles; 150 structured practices on ranks 1-15.

Confidence B overall unless a given title is marked A or C-E.
