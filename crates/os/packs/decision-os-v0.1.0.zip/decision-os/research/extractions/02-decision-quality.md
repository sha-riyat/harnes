# Extraction

title: "Decision Quality: Value Creation from Better Business Decisions"
authors: Carl Spetzler, Hannah Winter, Jennifer Meyer
year: 2016
publisher: Wiley
confidence: A
verify_url: https://www.wiley.com/en-us/Decision+Quality%3A+Value+Creation+from+Better+Business+Decisions-p-9781119144670

## Practices (paraphrased)

1. Treat decision quality as a six-link chain, not as a later win/loss.
2. The chain is only as strong as its weakest link: frame, alternatives, information, values, reasoning, commitment.
3. Frame the problem or opportunity before gathering more data.
4. Generate attractive alternatives; quality cannot exceed the best option you actually created.
5. Clarify values and trade-offs so analysis has somewhere to land.
6. Prefer relevant, reliable information over volume.
7. Apply sound reasoning under uncertainty, then get commitment to act.
8. Audit quality at decision time, before outcomes arrive.
9. Scale the same chain for significant everyday choices and for strategy.
10. Name the mental traps that quietly thin a link.

## Limits
Wiley March 2016 (ISBN 9781119144670). SDG / Stanford consulting lineage. Business-first. No PDF ingested.
