# Extraction

title: "Foundations of Decision Analysis"
authors: Ronald A. Howard, Ali E. Abbas
year: 2015
publisher: Pearson
confidence: A
verify_url: https://www.pearson.com/en-us/subject-catalog/p/Howard-Foundations-of-Decision-Analysis/P200000003532

## Practices (paraphrased)

1. Separate a decision from its outcome; luck does not rewrite the audit.
2. Use precise decision language so the conversation can be scored.
3. Clarify values before treating uncertainty as the whole problem.
4. Represent possibilities and uncertainty explicitly.
5. Follow rules of actional thought rather than vibes plus a spreadsheet.
6. Elicit risk attitude instead of assuming everyone is risk-neutral.
7. Run sensitivity analysis to see which uncertainties actually matter.
8. Treat a value measure as a comparison tool, not a moral score.
9. Seek clarity of action, not a perfect model of the world.
10. Teach DA as an evolutionary process, not a one-shot tree ritual.

## Limits
Pearson 1st edition published 21 Jan 2015 (©2016). Textbook length. No PDF.
