# Extraction

title: "Foundations of Decision Analysis"
authors: Ronald A. Howard, Ali E. Abbas
year: 2015
publisher: Pearson
confidence: A
verify_url: https://www.pearson.com/en-us/subject-catalog/p/Howard-Foundations-of-Decision-Analysis/P200000003532

## Practices (paraphrased)

1. Distinguish a decision from its outcome before scoring people.
2. Aim for clarity of action, not a perfect world-model.
3. Iterate the analysis.
4. Encode uncertainty as a probability you would bet on.
5. Use value of information to choose the next study.
6. Keep preference and forecast in different cells.
7. Treat ruin tails as load-bearing.
8. Write a reconstructable decision basis.
9. Refuse analysis theater that never commits.
10. Use the book as a methods text, not a pep talk.

## Limits
Pearson textbook depth. Wrong first book for an operator who only needs PrOACT.
