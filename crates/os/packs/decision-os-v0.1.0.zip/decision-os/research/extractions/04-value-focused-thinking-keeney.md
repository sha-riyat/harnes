# Extraction

title: "Value-Focused Thinking"
authors: Ralph L. Keeney
year: 1992
publisher: Harvard University Press
confidence: A
verify_url: https://www.hup.harvard.edu/books/9780674931985

## Practices (paraphrased)

1. Invent alternatives from objectives, not the reverse.
2. Separate means objectives from fundamental objectives.
3. Use a well-stated objective set as a creativity tool.
4. Surface stakeholder objectives.
5. Do not treat constraints as if they were objectives.
6. Refine the objective hierarchy iteratively.
7. Stop easy metrics from dominating unmeasured values.
8. Skip cargo-cult decision trees.
9. Treat linked decisions as a strategy.
10. Document values so you can audit drift.

## Limits
Academic monograph. Heavier than Smart Choices. Does not by itself handle recognition-primed incidents or Brier-scored questions.
