# Extraction

title: "Thinking, Fast and Slow"
authors: Daniel Kahneman
year: 2011
publisher: Farrar, Straus and Giroux
confidence: A
verify_url: https://us.macmillan.com/books/9780374533557/thinkingfastandslow/

## Practices (paraphrased)

1. Use System 1 / System 2 as a teaching sketch, not as two inner people.
2. Watch attribute substitution on hard questions.
3. Take an outside-view base rate before the inside story.
4. Rewrite loss and gain frames so both are visible.
5. Hunt missing cells (WYSIATI).
6. Demand calibration on confident percents.
7. Do not treat this book as a complete decision process.
8. Remember later Noise (2021) for scatter among judges.
9. Use reference-class forecasting against the planning fallacy.
10. Keep process tools; drop folklore chapters that aged badly.

## Limits
Public synthesis. Some headline social-priming material later shrank. Not a substitute for PrOACT or Decision Quality.
