# Extraction

title: "Thinking in Bets"
authors: Annie Duke
year: 2018
publisher: Portfolio / Penguin
confidence: A
verify_url: https://www.penguinrandomhouse.com/books/557226/thinking-in-bets-by-annie-duke/

## Practices (paraphrased)

1. Judge expected value under uncertainty, not the lucky headline.
2. Name resulting and refuse it in reviews.
3. Treat beliefs as priced bets.
4. Seek people who will take the other side.
5. Import hidden information and variance, not casino glamour.
6. Be honest about sample size when separating luck from skill.
7. Pre-commit to process before the scoreboard.
8. Speak in percents.
9. Collect independent estimates, then talk.
10. Keep the math honest; this is a popularization.

## Limits
Trade book. Useful resulting language; not a substitute for Hammond/Keeney/Raiffa or Howard/Abbas when a tree is required.
