# Extraction

title: "Sources of Power: How People Make Decisions"
authors: Gary Klein
year: 1998
publisher: MIT Press
confidence: A
verify_url: https://mitpress.mit.edu/9780262611466/sources-of-power/

## Practices (paraphrased)

1. Do not force a full alternative-comparison when time and expertise say otherwise.
2. Expect experts to recognize a workable first option and mentally simulate it.
3. Treat intuition as pattern recognition earned in a valid environment.
4. Use mental simulation to reject an option that will not work, not to invent a fantasy.
5. Look for leverage points instead of optimizing the whole tree.
6. Stories, analogues, and metaphors are how field experts share models.
7. Inspect whether team mind is a source of power or of cascade.
8. Watch hyperrational analysis fail under time pressure and shifting cues.
9. Study real incidents (fireground, cockpit), not only lab puzzles.
10. Hand the choice back to analysis when the environment is low-validity or the decision is linked and slow.

## Limits
MIT Press hardcover 1998; paperback listing 1999. Naturalistic decision making, not a PrOACT manual. No PDF.
