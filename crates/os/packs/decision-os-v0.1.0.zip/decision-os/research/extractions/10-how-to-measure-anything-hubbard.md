# Extraction

title: "How to Measure Anything"
authors: Douglas W. Hubbard
year: 2007
publisher: Wiley
confidence: B
verify_url: https://www.wiley.com/en-us/How+to+Measure+Anything%3A+Finding+the+Value+of+Intangibles+in+Business%2C+3rd+Edition-p-9781118539279

## Practices (paraphrased)

1. If it matters and is uncertain, it is measurable in a decision-relevant sense.
2. Start with a calibrated 90 percent interval.
3. Compute expected value of information before buying a study.
4. Drop measurements that cannot change the act.
5. Prefer quantitative ranges to risk-matrix colors.
6. Define the decision before calling something intangible.
7. Decompose blob estimates.
8. Sample the driver that actually flips the choice.
9. Do not quantify dignity away.
10. Pair with Keeney so unmeasured fundamentals stay visible.

## Limits
Applied information economics, graded B as selected adjacent. Later editions 2010/2014 exist; first listing is 2007.
