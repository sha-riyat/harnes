# Extraction

title: "Smart Choices: A Practical Guide to Making Better Decisions"
authors: John S. Hammond, Ralph L. Keeney, Howard Raiffa
year: 1999
publisher: Harvard Business School Press
confidence: A
verify_url: https://store.hbr.org/product/smart-choices-a-practical-guide-to-making-better-decisions/15040

## Practices (paraphrased)

1. Name the decision problem before you compare offers; a vendor menu is not a frame.
2. Write objectives first. Alternatives that appear before objectives will shrink the set.
3. Use PrOACT as the checklist: Problem, Objectives, Alternatives, Consequences, Trade-offs.
4. Put consequences, including intangibles, in a table you can see.
5. Make trade-offs with even-swaps or explicit weights, not with a vibe.
6. Add uncertainty, risk tolerance, and linked later decisions when they are actually present.
7. Divide and conquer: decompose the elements, then reassemble.
8. Seek choices that advance long-term objectives instead of only extinguishing fires.
9. Judge the process; a good process can still lose.
10. Skip the full analysis on reversible, low-stakes choices.

## Limits
Paraphrase of the public PrOACT argument (HBS Press 1999; later HBR Press reprint on this store URL). Managerial and personal examples; not a MAUT textbook. No quotations or PDF.
