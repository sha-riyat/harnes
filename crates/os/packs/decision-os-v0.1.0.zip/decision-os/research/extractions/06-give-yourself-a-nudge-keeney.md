# Extraction

title: "Give Yourself a Nudge: Helping Smart People Make Smarter Personal and Business Decisions"
authors: Ralph L. Keeney
year: 2020
publisher: Cambridge University Press
confidence: A
verify_url: https://www.cambridge.org/core/books/give-yourself-a-nudge/F9449A09F0A05B88074563EE38E602A3

## Practices (paraphrased)

1. Create decision opportunities, do not only fight problems.
2. Rewrite the frame toward objectives you actually want.
3. List personal and business objectives before options.
4. Invent alternatives off the menu you were handed.
5. Treat problem-solving as restoration and opportunities as raising life quality.
6. Ask who must authorize an alternative you do not control.
7. Apply nudges to yourself, not as covert control of others.
8. Practice value-focused deciding as a habit.
9. Keep a short dated life-quality objective list.
10. Do not use this book as the only method on a nuclear-scale public decision.

## Limits
Verified personal-side extension of Keeney's program. Still not a complete corpus for marriage, migration, or other irreversible life bets.
