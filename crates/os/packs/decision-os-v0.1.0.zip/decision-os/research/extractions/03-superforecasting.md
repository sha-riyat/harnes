# Extraction

title: "Superforecasting: The Art and Science of Prediction"
authors: Philip E. Tetlock, Dan Gardner
year: 2015
publisher: Crown
confidence: A
verify_url: https://www.penguinrandomhouse.com/books/227815/superforecasting-by-philip-e-tetlock-and-dan-gardner/

## Practices (paraphrased)

1. State beliefs as probabilities that can be scored, not as slogans.
2. Update when evidence arrives; refusing to move is not grit.
3. Break a question into Fermi sub-questions before you answer the whole.
4. Take the outside view first, then the inside view.
5. Prefer teams whose errors are independent over a charismatic expert.
6. Keep a prediction log; unaided memory will flatter you.
7. Write questions that resolve; vague wording is not a forecast.
8. Train calibration so you are neither systematically timid nor cocky.
9. Do not treat storytelling fluency as predictive skill.
10. Treat the habits as trainable; this is not a mystic caste.

## Limits
Crown / PRH 2015. Popular report of the Good Judgment Project; IARPA ACE scoring papers remain the paper-heavy layer. Not a substitute for a values table. No PDF.
