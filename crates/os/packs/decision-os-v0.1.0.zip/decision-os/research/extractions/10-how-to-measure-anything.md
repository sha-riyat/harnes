# Extraction

title: "How to Measure Anything: Finding the Value of Intangibles in Business"
authors: Douglas W. Hubbard
year: 2007
publisher: Wiley
confidence: B
verify_url: https://www.wiley.com/en-us/How+to+Measure+Anything%3A+Finding+the+Value+of+Intangibles+in+Business%2C+3rd+Edition-p-9781118539279

## Practices (paraphrased)

1. If a number matters and is uncertain, it is measurable in the information sense.
2. Define the decision first so a measurement has expected value of information.
3. Calibrate estimators before trusting expert ranges.
4. A 90 percent interval that never contains the truth is not 90 percent.
5. Prefer a cheap observation that narrows the range over a fake-precise average.
6. Treat "intangible" as a failure of operational definition more often than of metaphysics.
7. Monte Carlo the uncertainty instead of managing to a point estimate.
8. Do not measure everything; measure what would change the choice.
9. Use later-edition risk and customer-satisfaction examples without changing the claim.
10. Do not let measurement replace Keeney values or Tetlock scoring.

## Limits
Wiley first edition 2007; 3rd edition March 2014 commonly listed. Confidence B so quantification does not crowd out unmeasured fundamental objectives. No PDF.
