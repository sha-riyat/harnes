# Extraction

title: "Sources of Power"
authors: Gary Klein
year: 1998
publisher: MIT Press
confidence: A
verify_url: https://mitpress.mit.edu/9780262611466/sources-of-power/

## Practices (paraphrased)

1. In high-validity time pressure, experts often take the first workable option.
2. Recognition-primed deciding is pattern match plus mental simulation.
3. Do not force a full PrOACT table onto a fireground clock.
4. Novices should not copy expert shortcuts.
5. Treat operator stories and analogs as data.
6. Switch back to analysis when validity is low or the setting is new.
7. Hand off to intuitive-os when time and validity say so.
8. Watch procedure worship when the map no longer matches the terrain.
9. After-action, ask what was recognized.
10. Klein limits analysis; it does not license unaccountable gut on a slow bet.

## Limits
Field studies of skilled operators. Not a forecasting manual and not a values-elicitation manual.
