# Extraction

title: "Smart Choices: A Practical Guide to Making Better Decisions"
authors: John S. Hammond, Ralph L. Keeney, Howard Raiffa
year: 1999
publisher: Harvard Business School Press
confidence: A
verify_url: https://store.hbr.org/product/smart-choices-a-practical-guide-to-making-better-decisions/15040

## Practices (paraphrased)

1. Frame the problem before comparing options (PrOACT).
2. Put objectives first and alternatives second, or you will choose among the wrong set.
3. Make consequences visible in a table, including intangibles.
4. Make trade-offs with even-swaps or weights, not vibes.
5. Treat uncertainty, risk tolerance, and linked decisions as extra elements.
6. Do not let a vendor's option set become the problem definition.
7. Seek decisions that advance long-term objectives, not only fires.
8. Divide and conquer: decompose, then reassemble.
9. A good process can still lose; judge the process.
10. Skip full analysis on reversible trivial choices.

## Limits
The 1999 HBS Press book is a practitioner synthesis of decision analysis, not a MAUT monograph. It does not replace Klein when seconds and high validity apply, and it does not by itself score forecasts.
