# Extraction

title: "Superforecasting: The Art and Science of Prediction"
authors: Philip E. Tetlock, Dan Gardner
year: 2015
publisher: Crown
confidence: A
verify_url: https://www.penguinrandomhouse.com/books/227815/superforecasting-by-philip-e-tetlock-and-dan-gardner/

## Practices (paraphrased)

1. Make forecasts probabilistic and scored.
2. Update when evidence arrives.
3. Fermi-ize blob questions.
4. Take the outside view first.
5. Prefer teams of independent errors to a charismatic expert.
6. Keep a prediction log.
7. Avoid wording that cannot be resolved.
8. Train calibration, not swagger.
9. Do not confuse storytelling with predictive skill.
10. Treat the habits as trainable.

## Limits
GJP / IARPA tournament evidence is stronger than any airport-book parable. Many scoring details live in papers, not this trade book. Superforecasting is not a values table.
