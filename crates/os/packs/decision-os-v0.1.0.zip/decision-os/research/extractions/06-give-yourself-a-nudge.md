# Extraction

title: "Give Yourself a Nudge: Helping Smart People Make Smarter Personal and Business Decisions"
authors: Ralph L. Keeney
year: 2020
publisher: Cambridge University Press
confidence: A
verify_url: https://www.cambridge.org/core/books/give-yourself-a-nudge/F9449A09F0A05B88074563EE38E602A3

## Practices (paraphrased)

1. Create decision opportunities; do not wait for problems that only restore the status quo.
2. Nudge yourself by naming objectives before you shop a received menu.
3. Define the decision you actually face; a sloppy frame is already a choice.
4. Identify values thoroughly enough that new alternatives become visible.
5. Generate alternatives instead of picking among the first three that appear.
6. Seek authorization when the alternative you need is controlled by someone else.
7. Treat personal life quality as the point of the skill, not a footnote.
8. Use evaluation tools only after the qualitative map exists.
9. Do not confuse this self-nudge with Thaler/Sunstein choice architecture.
10. Resolving a problem is not the same as improving a life.

## Limits
CUP April 2020 (ISBN 9781108715621). Verified personal-side extension of value-focused thinking, not a complete corpus on marriage or migration. No PDF.
