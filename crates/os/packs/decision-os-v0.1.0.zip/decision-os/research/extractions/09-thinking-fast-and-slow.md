# Extraction

title: "Thinking, Fast and Slow"
authors: Daniel Kahneman
year: 2011
publisher: Farrar, Straus and Giroux
confidence: A
verify_url: https://us.macmillan.com/books/9780374275631/thinkingfastandslow/

## Practices (paraphrased)

1. Expect System 1 to answer first; invite System 2 on purpose.
2. Use the outside view and a reference class on plans that feel unique.
3. Do not let a vivid story replace a base rate.
4. Watch overconfidence when the narrative is fluent.
5. Treat loss aversion and framing as movers of choice, not as footnotes.
6. Notice substitution: answering an easier question than the one asked.
7. Remember WYSIATI: what you see is not all there is.
8. Do not substitute a bias label for a values table or a forecast log.
9. Spend slow thinking on high-stakes or low-validity cases; it is costly.
10. Keep modest confidence on any single heuristic name; this is a popular synthesis.

## Limits
FSG 25 Oct 2011. Diagnosis of unaided judgment, not a values table. No PDF.
