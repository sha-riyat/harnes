# Extraction

title: "Decision Quality: Value Creation from Better Business Decisions"
authors: Carl Spetzler, Hannah Winter, Jennifer Meyer
year: 2016
publisher: Wiley
confidence: A
verify_url: https://www.wiley.com/en-us/Decision+Quality%3A+Value+Creation+from+Better+Business+Decisions-p-9781119144670

## Practices (paraphrased)

1. Score a decision on six requirements; quality is limited by the weakest link.
2. Separate a good decision from a good outcome before anyone celebrates or blames.
3. Write the frame: what is decided now, what is out of scope, who decides.
4. Refuse a one-option decision; invent distinctly different alternatives.
5. Demand relevant and reliable information; more slides are not more information.
6. Clarify values and trade-offs before the model runs.
7. Use sound reasoning that another analyst can reconstruct.
8. Require commitment to action and named owners.
9. Judge decision quality at the time of choice.
10. Scale the process to the value at stake.

## Limits
SDG/Stanford consulting lineage. Strong on strategic business decisions; lighter on personal irreversible choices and on fast-and-frugal environments.
