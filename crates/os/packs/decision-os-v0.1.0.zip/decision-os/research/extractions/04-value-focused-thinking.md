# Extraction

title: "Value-Focused Thinking: A Path to Creative Decisionmaking"
authors: Ralph L. Keeney
year: 1992
publisher: Harvard University Press
confidence: A
verify_url: https://books.google.com/books/about/Value_Focused_Thinking.html?id=I-goT2wc2IkC

## Practices (paraphrased)

1. State fundamental objectives before listing alternatives.
2. Separate ends from means so the OS does not optimize a proxy.
3. Use the value structure to invent alternatives, not only to score a received menu.
4. Build the qualitative objectives map first; numbers come second.
5. Quantify only what the qualitative map has already made honest.
6. Convert a decision problem into a decision opportunity by asking what else would serve these values.
7. Let values decide which information is worth collecting.
8. Elicit hidden and stakeholder objectives; they otherwise steer off-stage.
9. Treat a shared objectives structure as the group language.
10. Document values so later you can audit drift on linked decisions.

## Limits
HUP 1992. Corporate and public-sector cases dominate. Utility modeling can flatten sacred values if you force one scale. No PDF.
