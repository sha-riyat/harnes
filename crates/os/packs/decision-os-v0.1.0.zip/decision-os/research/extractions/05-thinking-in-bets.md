# Extraction

title: "Thinking in Bets: Making Smarter Decisions When You Don't Have All the Facts"
authors: Annie Duke
year: 2018
publisher: Portfolio / Penguin
confidence: A
verify_url: https://www.penguinrandomhouse.com/books/552885/thinking-in-bets-by-annie-duke/

## Practices (paraphrased)

1. Judge a decision by expected value under uncertainty, not by the later headline.
2. Name resulting as a learning poison: outcomes are not a process audit.
3. Treat every belief as a bet with a probability.
4. Recruit people who will bet against your story.
5. Import hidden-information and variance habits from poker; leave casino glamour.
6. Separate luck from skill with honest sample size.
7. Pre-commit to process so mood after the result cannot rewrite the history.
8. Say "I am 60 percent" instead of "I know."
9. Collect independent estimates, then discuss.
10. Keep the math honest; this is a popularization of older DA ideas.

## Limits
Portfolio 6 Feb 2018. Trade book. How to Decide (2020) is a workbook companion, not a second theory. No PDF.
