# Decision OS

Structure choices with PrOACT, values, and scored forecasts — judge process, not luck.

Wave 0 factory OS. Load `manifest.yaml`. Doctrine in `OS.md`. Judgments in `oracle/ORACLE.md`.

Depends on: research-os, ai-logic-os, evaluation-os.

Confidence: A. Quality target ≥90, floor 7 per category.

## Quick start
1. Lint: `python3 scripts/lint-os.py --os decision-os`
2. Route an intent from `routing/intents.yaml`
3. Run a skill under `skills/`
4. Score with `evals/suite.yaml`
