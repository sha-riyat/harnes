# Example: job-move

Frame: city move vs stay. Objectives: craft growth, kin time, runway. Alts include delay 6 months. Forecast: 55% that craft growth actually happens in the new job within a year.
