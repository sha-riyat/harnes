    # Skill: generate-alts

    **Purpose:** Invent alternatives from objectives.

    **When to use:** Too few options.

    **Steps:**
    1. Value-focused generation.
2. Add a none and a delay.
3. Kill dominated alts.
4. Keep a wild but legal option.

    **Failure modes:**
    - Illegal alternatives
- schema-invalid input

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
