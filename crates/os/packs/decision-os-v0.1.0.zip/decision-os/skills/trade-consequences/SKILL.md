    # Skill: trade-consequences

    **Purpose:** Table consequences and even-swap trades.

    **When to use:** Hard trade-off.

    **Steps:**
    1. Consequences including intangibles.
2. Make a trade explicit.
3. Record risk tolerance.
4. Do not hide sacred values in a spreadsheet.

    **Failure modes:**
    - Pretend all can be maximized
- schema-invalid input

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
