    # Skill: frame-decision

    **Purpose:** Frame problem, objectives, owners.

    **When to use:** Sticky choice.

    **Steps:**
    1. Write the problem.
2. List fundamental objectives.
3. Name linked decisions.
4. Catch a vendor-framed option set.

    **Failure modes:**
    - Crime planning
- schema-invalid input

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
