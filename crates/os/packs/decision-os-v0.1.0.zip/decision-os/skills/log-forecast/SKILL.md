    # Skill: log-forecast

    **Purpose:** Log a probabilistic forecast to score later.

    **When to use:** Uncertainty dominates.

    **Steps:**
    1. Write a resolvable question.
2. Give a probability.
3. Outside view first.
4. Schedule resolution.

    **Failure modes:**
    - Unresolvable mystic question
- schema-invalid input

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
