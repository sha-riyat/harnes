# agk adapter — decision-os

Purpose of this OS: Structure choices with PrOACT, values, and scored forecasts — judge process, not luck.

## Mapping
Load this OS as an AGK pole pack. Map agents to AGK agent files, skills to AGK skills, memory/seed.yaml to AGK memory, routing/intents.yaml to AGK command dispatch.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
AGK-specific plugins not defined here; use adapters as the contract only.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
