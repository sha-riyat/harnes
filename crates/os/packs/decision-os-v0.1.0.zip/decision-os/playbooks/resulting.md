# Playbook: resulting

A good process can lose. Log it that way.
