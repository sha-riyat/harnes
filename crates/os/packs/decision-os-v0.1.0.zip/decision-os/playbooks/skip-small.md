# Playbook: skip-small

If cheap and reversible, pick and move. Analysis is a cost.
