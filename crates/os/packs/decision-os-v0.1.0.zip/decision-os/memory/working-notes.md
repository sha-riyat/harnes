Working notes are not oracle. Wave 1 Personal generated 2026-08-24 on-box. No GitHub clone. No Circle. English only.
