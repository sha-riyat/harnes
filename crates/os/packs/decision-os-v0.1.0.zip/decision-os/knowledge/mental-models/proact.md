# PrOACT

Problem, objectives, alternatives, consequences, trade-offs; plus uncertainty, risk, linked decisions.
