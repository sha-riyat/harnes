# Outside view first

Tetlock/Kahneman: base rates before inside story.
