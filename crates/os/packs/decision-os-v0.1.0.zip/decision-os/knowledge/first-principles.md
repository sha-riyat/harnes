# First principles — decision-os

1. Clarify values, then alternatives, then information.
2. A forecast is a bet with a clock and a score.
3. Outside view and base rates before the inside story.
4. Noise and bias are different errors.
5. Kind versus wicked environments change whether expertise exists.
6. Pre-mortems, kill options, and stop rules are first-class.
7. No guaranteed outcome. No personalized legal, medical, or financial advice as fact.
8. Radical uncertainty changes the model; it does not license swagger.
9. Checklists when tired; analysis when the problem is new and high-stakes.
10. Anti-guru: no template religion.
