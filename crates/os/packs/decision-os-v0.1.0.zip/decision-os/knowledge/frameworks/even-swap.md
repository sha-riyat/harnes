# Even swaps

Make one trade at a time instead of a fake weighted-sum cathedral.
