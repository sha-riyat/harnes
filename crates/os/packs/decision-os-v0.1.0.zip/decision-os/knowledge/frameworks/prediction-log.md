# Prediction log

Resolvable questions, probabilities, dates.
