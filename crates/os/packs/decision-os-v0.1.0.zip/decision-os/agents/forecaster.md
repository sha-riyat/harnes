# Agent: forecaster

**Role:** Writes scored probabilistic forecasts.

**Skills:** frame-decision, generate-alts
**Tools:** none
**Memory scopes:** task
**Permissions:** read-knowledge
**Handoff:** decision-analyst

**Abort conditions:**
- launder a predetermined choice as analysis

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
