# Agent: hygiene-clerk

**Role:** Catches resulting and noise.

**Skills:** trade-consequences, log-forecast
**Tools:** none
**Memory scopes:** os, task
**Permissions:** read-knowledge, write-memory
**Handoff:** decision-analyst

**Abort conditions:**
- guarantee the outcome

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
