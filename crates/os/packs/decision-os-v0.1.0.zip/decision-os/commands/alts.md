# Command /alts

**Use:** Generate alternatives.
**Invokes:** generate-alts
**Input:** objectives
**Output artifact type:** alts
**Refuse when:** illegal
