# Command /forecast

**Use:** Log forecast.
**Invokes:** log-forecast
**Input:** question
**Output artifact type:** forecast
**Refuse when:** unresolvable
