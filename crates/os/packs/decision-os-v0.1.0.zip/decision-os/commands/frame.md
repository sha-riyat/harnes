# Command /frame

**Use:** Frame a decision.
**Invokes:** frame-decision
**Input:** mess
**Output artifact type:** frame
**Refuse when:** crime
