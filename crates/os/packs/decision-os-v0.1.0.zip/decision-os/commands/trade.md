# Command /trade

**Use:** Trade table.
**Invokes:** trade-consequences
**Input:** alts
**Output artifact type:** table
**Refuse when:** none
