# Working notes — positioning-os

Depends on market-research-os for evidence. Brand-os owns identity systems. Offer-os owns the promise boundaries.
