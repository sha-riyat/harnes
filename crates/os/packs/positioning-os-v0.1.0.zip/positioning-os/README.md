# Positioning OS

Wave 4 Grow OS. Occupy a distinct place in a named comparison set — category, alternatives, difference, and proof — not a tagline contest.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (28 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: research-os, evaluation-os, market-research-os.
