# Command /claim-difference

**Use:** Write a valued, testable difference.
**Invokes:** claim-difference
**Input:** difference
**Output artifact type:** claim-difference-artifact
**Refuse when:** Adjective pile
