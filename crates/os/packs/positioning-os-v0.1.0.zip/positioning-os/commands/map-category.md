# Command /map-category

**Use:** Name the category and the ladder rungs.
**Invokes:** map-category
**Input:** field
**Output artifact type:** map-category-artifact
**Refuse when:** Category-as-incorporation-papers
