# Command /list-alternatives

**Use:** List the real comparison set including do-nothing.
**Invokes:** list-alternatives
**Input:** segment
**Output artifact type:** list-alternatives-artifact
**Refuse when:** Invented rivals
