# Command /draft-position

**Use:** Assemble an internal position brief.
**Invokes:** draft-position
**Input:** inputs
**Output artifact type:** draft-position-artifact
**Refuse when:** Tagline contest
