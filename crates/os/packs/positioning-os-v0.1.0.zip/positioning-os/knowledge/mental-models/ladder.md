# Category ladder

Rungs in the mind. Late arrivals need an unoccupied rung or a new ladder.
