# Comparison set

Dunford: you are positioned against what they think they could do instead.
