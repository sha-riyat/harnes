# First principles — positioning-os

1. A position lives in a comparison set in the buyer's mind, not on a product slide.
2. Category is a choice you can test, not a destiny from incorporation papers.
3. Difference must be sayable and important to the buyer, not only to the product team.
4. Line extension often blurs the word you already own.
5. Names are strategy.
6. Reposition a rival only with a verifiable fact.
7. A workshop output is a hypothesis until win/loss notes agree.
8. Distinctive assets and a real difference are not the same job; pair Ries/Trout with Ehrenberg-Bass.
9. No promised category ownership or revenue from a positioning offsite.
10. Anti-guru: no tagline contest as a strategy; no weekend transformation.
