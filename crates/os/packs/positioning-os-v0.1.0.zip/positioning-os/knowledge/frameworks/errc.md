# ERRC / value curve

Eliminate, reduce, raise, create. A sketch, not a proof.
