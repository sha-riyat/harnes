# Where to play / how to win

Lafley/Martin cascade. Position is the how-to-win sentence in a chosen playing field.
