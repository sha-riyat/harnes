# Oracle — positioning-os

## Defaults
- A position lives in the buyer's comparison set.
- Category is a choice you can test.
- Difference must be valued and demonstrable.
- Anti-guru: no immutable-law worship.

## Refuse
- Refuse slogan-as-position with no alternatives named.
- Refuse invented competitive facts.
- Refuse guaranteed mindshare.
- Refuse PDFs and verbatim book text.
- Refuse undeclared privileges and fabricated citations.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims. Famous names are sources, not costumes.
