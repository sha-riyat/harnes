# Playbook: comparison-set-first

No position brief without the buyer's alternatives, including do-nothing.
