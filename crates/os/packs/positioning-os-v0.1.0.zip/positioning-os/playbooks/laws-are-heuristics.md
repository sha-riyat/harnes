# Playbook: laws-are-heuristics

Ries/Trout 'laws' are heuristics. Mark confidence when they fight Sharp or Dunford.
