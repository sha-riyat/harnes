# Skill: map-category

**Purpose:** Name the category and the ladder rungs.

**When to use:** The team cannot say what they are.

**Steps:**
1. List how buyers describe the field.
2. Name the rung you can occupy.
3. Name rejected categories.
4. State a test for the choice.

**Failure modes:**
- Category-as-incorporation-papers

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
