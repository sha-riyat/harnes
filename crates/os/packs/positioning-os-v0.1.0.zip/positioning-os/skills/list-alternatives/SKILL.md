# Skill: list-alternatives

**Purpose:** List the real comparison set including do-nothing.

**When to use:** A deck talks only about us.

**Steps:**
1. Name status quo.
2. Name direct and indirect alternatives as buyers do.
3. Mark switching costs.
4. Drop fake rivals nobody considers.

**Failure modes:**
- Invented rivals

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
