# Skill: draft-position

**Purpose:** Assemble an internal position brief.

**When to use:** Go-to-market needs a single story.

**Steps:**
1. Restate category, alternatives, difference, best-fit.
2. Translate to sales and web constraints.
3. List kill criteria.
4. Hand copy tone to brand-os, not as identity.

**Failure modes:**
- Tagline contest

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
