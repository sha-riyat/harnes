# Skill: claim-difference

**Purpose:** Write a valued, testable difference.

**When to use:** Features are listed without a difference.

**Steps:**
1. State the difference in buyer language.
2. Attach proof or a proof gap.
3. Ask if a rival could say the same tomorrow.
4. Bound what you will not claim.

**Failure modes:**
- Adjective pile

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
