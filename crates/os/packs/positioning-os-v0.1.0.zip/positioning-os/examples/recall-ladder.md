# Example: recall-ladder

Field: clinic patient outreach. Alternatives: front-desk calls, generic SMS blasts, do nothing. Difference: protocol-tied recall with confirmation, not marketing blasts. Best-fit: multi-site clinics with a named protocol owner. Proof gap: one measured no-show change. Kill if buyers describe us as 'just SMS marketing'.
