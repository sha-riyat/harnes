# Synthesis — positioning-os (deepen wave 4-5)

This pack now carries a deepened research layer: 52 ranked real titles and 150 paraphrased practices on the selected top 15 (10 each). Existing bibliographic work was kept and extended; no titles were invented; no PDFs were packaged; GitHub was not cloned.

Practices use the structured extraction schema (insight_id, source, concept, principle, mechanism, when_to_use, when_not, example, confidence A-E). Depth note: hand-authored structured extraction on ranks 1-15.

Anti-guru and money boundaries stay in force: educate and organize; verify or omit; no promised revenue, growth, quota, or virality; no fabricated sources; no dark-pattern methods.

Gap note: B2B practical process (Dunford) plus Ries/Trout are dense. Public-sector and internal-platform positioning texts are thinner. Deepen wave 4-5: 52 ranked titles; 150 structured practices on ranks 1-15 (hand-authored ranks 1-15). Deepen wave 4-5: 52 ranked titles; 150 structured practices on ranks 1-15 (hand-authored ranks 1-15).

Confidence B overall unless a given title is marked A or C-E.
