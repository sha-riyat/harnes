# Bugfix loop

1. Reproduce with the smallest command or test. Capture the failure.
2. Locate the cause with search and a narrow read; do not rewrite the area.
3. Add a regression test that fails for the right reason.
4. Fix the cause, not the symptom. Keep the diff one-purpose.
5. Run the regression test and the nearest broader suite.
6. Report: reproduction, cause, files, commands, result, residual risk.
