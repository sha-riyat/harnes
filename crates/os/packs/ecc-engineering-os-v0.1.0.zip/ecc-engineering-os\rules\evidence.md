# Evidence

Every report line points to a file, a command, an event or a check. Record the command's exit code and a short tail of its output. Quote paths exactly.
