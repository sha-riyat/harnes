# Feature TDD

1. Turn the request into observable guarantees.
2. Write the failing test (RED) and capture the output.
3. Implement the smallest green change (GREEN).
4. Refactor only under a green check.
5. Run unit + integration + e2e checks that the project actually has.
6. Report the RED/GREEN evidence and any unverified path.
