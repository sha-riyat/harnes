# Provenance

- Source: https://github.com/affaan-m/ECC
- License: MIT (see LICENSE-ECC)
- Pinned commit: 90606c8315ee09cafc303515c5f33024db6b9882
- Upstream author: Affaan Mustafa
- Selection: 48 skills, curated for harnes; not the full ECC catalogue.

## Copied verbatim
- skills/tdd-workflow/
- skills/verification-loop/
- skills/error-handling/
- skills/coding-standards/
- skills/git-workflow/
- skills/rust-patterns/
- skills/rust-testing/
- skills/python-patterns/
- skills/python-testing/
- skills/golang-patterns/
- skills/golang-testing/
- skills/java-coding-standards/
- skills/kotlin-patterns/
- skills/kotlin-testing/
- skills/cpp-coding-standards/
- skills/cpp-testing/
- skills/csharp-testing/
- skills/perl-patterns/
- skills/react-patterns/
- skills/react-testing/
- skills/react-performance/
- skills/frontend-patterns/
- skills/backend-patterns/
- skills/api-design/
- skills/database-migrations/
- skills/postgres-patterns/
- skills/mysql-patterns/
- skills/redis-patterns/
- skills/docker-patterns/
- skills/kubernetes-patterns/
- skills/e2e-testing/
- skills/browser-qa/
- skills/architecture-decision-records/
- skills/hexagonal-architecture/
- skills/production-audit/
- skills/deployment-patterns/
- skills/ai-regression-testing/
- skills/module-regression/
- skills/change-impact/
- skills/codebase-onboarding/
- skills/code-tour/
- skills/repo-scan/
- skills/regex-vs-llm-structured-text/
- skills/benchmark-methodology/
- skills/benchmark-optimization-loop/
- skills/windows-desktop-e2e/
- skills/frontend-a11y/
- skills/accessibility/

## harnes wrappers

manifest.yaml, OS.md, oracle/ORACLE.md, routing/intents.yaml, playbooks/, rules/, agents/, NOTICE and this file were written for harnes. They do not modify the copied skills.
