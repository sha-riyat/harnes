# Oracle â€” ECC Engineering OS

## Non-negotiables
- No behavior change without a check that would have caught it.
- No unrelated cleanup in a bugfix diff.
- No invented test output or file contents.
- No deletion of user work to make a test pass.
- Dependencies need a license and a reason; prefer the standard library.

## Attribution

ECC is MIT-licensed. Keep LICENSE-ECC, NOTICE and PROVENANCE.md with the pack. Do not relicense ECC content.
