# ECC Engineering OS

## Purpose
Bring ECC's engineering discipline into harnes: test-first changes, small diffs, language-specific correctness, migrations, deployment checks and browser evidence.

## Runtime loop
1. Read the task and find the affected files.
2. Route to a language or workflow skill; load only the skills you will use.
3. Write or identify the failing check before changing behavior.
4. Make the smallest change; run the project's own command.
5. Review the diff for scope, security and tests.
6. Record the command and result in the worker report.

## Refuse
Claiming a test passes without output, rewriting unrelated code, suppressing a failing check, merging with unresolved conflicts, or adding a dependency without a license and security check.

## Skills
- tdd-workflow: skills/tdd-workflow/SKILL.md
- verification-loop: skills/verification-loop/SKILL.md
- error-handling: skills/error-handling/SKILL.md
- coding-standards: skills/coding-standards/SKILL.md
- git-workflow: skills/git-workflow/SKILL.md
- rust-patterns: skills/rust-patterns/SKILL.md
- rust-testing: skills/rust-testing/SKILL.md
- python-patterns: skills/python-patterns/SKILL.md
- python-testing: skills/python-testing/SKILL.md
- golang-patterns: skills/golang-patterns/SKILL.md
- golang-testing: skills/golang-testing/SKILL.md
- java-coding-standards: skills/java-coding-standards/SKILL.md
- kotlin-patterns: skills/kotlin-patterns/SKILL.md
- kotlin-testing: skills/kotlin-testing/SKILL.md
- cpp-coding-standards: skills/cpp-coding-standards/SKILL.md
- cpp-testing: skills/cpp-testing/SKILL.md
- csharp-testing: skills/csharp-testing/SKILL.md
- perl-patterns: skills/perl-patterns/SKILL.md
- react-patterns: skills/react-patterns/SKILL.md
- react-testing: skills/react-testing/SKILL.md
- react-performance: skills/react-performance/SKILL.md
- frontend-patterns: skills/frontend-patterns/SKILL.md
- backend-patterns: skills/backend-patterns/SKILL.md
- api-design: skills/api-design/SKILL.md
- database-migrations: skills/database-migrations/SKILL.md
- postgres-patterns: skills/postgres-patterns/SKILL.md
- mysql-patterns: skills/mysql-patterns/SKILL.md
- redis-patterns: skills/redis-patterns/SKILL.md
- docker-patterns: skills/docker-patterns/SKILL.md
- kubernetes-patterns: skills/kubernetes-patterns/SKILL.md
- e2e-testing: skills/e2e-testing/SKILL.md
- browser-qa: skills/browser-qa/SKILL.md
- architecture-decision-records: skills/architecture-decision-records/SKILL.md
- hexagonal-architecture: skills/hexagonal-architecture/SKILL.md
- production-audit: skills/production-audit/SKILL.md
- deployment-patterns: skills/deployment-patterns/SKILL.md
- ai-regression-testing: skills/ai-regression-testing/SKILL.md
- module-regression: skills/module-regression/SKILL.md
- change-impact: skills/change-impact/SKILL.md
- codebase-onboarding: skills/codebase-onboarding/SKILL.md
- code-tour: skills/code-tour/SKILL.md
- repo-scan: skills/repo-scan/SKILL.md
- regex-vs-llm-structured-text: skills/regex-vs-llm-structured-text/SKILL.md
- benchmark-methodology: skills/benchmark-methodology/SKILL.md
- benchmark-optimization-loop: skills/benchmark-optimization-loop/SKILL.md
- windows-desktop-e2e: skills/windows-desktop-e2e/SKILL.md
- frontend-a11y: skills/frontend-a11y/SKILL.md
- accessibility: skills/accessibility/SKILL.md

## Load contract
Load manifest.yaml, bind oracle/ORACLE.md, route via routing/intents.yaml, execute skills/workflows, emit typed artifacts, and keep evidence for every claim.

## Evidence
A command result, a file:line reference, an eval check, or a telemetry event is evidence. A feeling is not. If a check was not run, say so.

## Provenance
Source: https://github.com/affaan-m/ECC (MIT), pinned at 90606c8315ee09cafc303515c5f33024db6b9882.
The skills/ trees are copied verbatim from ECC. OS.md, oracle/, playbooks/, rules/, NOTICE and PROVENANCE.md are harnes wrappers. See LICENSE-ECC.
