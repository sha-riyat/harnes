# Small diffs

One purpose per change. Preserve public behavior unless the task asks for it. Do not mix formatting, renames, dependency upgrades and behavior in one diff. A fix that needs a rewrite is a design discussion, not a silent rewrite.
