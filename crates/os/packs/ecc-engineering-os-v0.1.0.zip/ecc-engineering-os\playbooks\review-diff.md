# Review a diff

1. Read the task and the diff, not the author's summary first.
2. Check behavior, error paths, authz, data loss and concurrency.
3. Check that tests fail without the fix and cover the edge cases.
4. Check scope: unrelated edits, generated files, secrets, lockfiles.
5. Rank findings: blocking, should-fix, nit. A blocking finding needs a concrete failure mode.
6. Do not approve a diff you cannot explain or reproduce.
