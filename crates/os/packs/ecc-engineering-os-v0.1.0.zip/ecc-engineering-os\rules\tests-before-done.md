# Tests before done

No claim of passing without a command and its output. A test that was not run is not_verified, not passed. A test that fails for the wrong reason does not count.
