# Command /refactor

**Use:** Safe refactor plan.
**Invokes:** refactor-safe
**Input:** smell + tests
**Output artifact type:** safe-refactor
**Refuse when:** no tests or characterization
