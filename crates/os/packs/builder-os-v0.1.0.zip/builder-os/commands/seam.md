# Command /seam

**Use:** Legacy isolation.
**Invokes:** isolate-legacy
**Input:** blob + change
**Output artifact type:** legacy-seam
**Refuse when:** big-bang rewrite
