# Command /review

**Use:** Review a diff.
**Invokes:** review-diff
**Input:** diff summary
**Output artifact type:** diff-review
**Refuse when:** rewrite-as-review
