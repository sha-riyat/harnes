# Command /plan

**Use:** Construction plan.
**Invokes:** construction-plan
**Input:** change + risks
**Output artifact type:** construction-plan
**Refuse when:** no verification
