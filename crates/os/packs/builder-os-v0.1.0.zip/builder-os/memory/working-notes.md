# Working notes — builder-os

Not a replacement for quality-evaluation-os (product quality argument) or release-os (path to prod).
