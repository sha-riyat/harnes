# Playbook: one-purpose-diff

Feature or refactor. Not both in an unreadable bundle.
