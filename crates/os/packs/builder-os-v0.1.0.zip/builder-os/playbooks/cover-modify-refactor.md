# Playbook: cover-modify-refactor

Feathers order: cover, modify, refactor. Not the reverse.
