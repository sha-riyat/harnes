# Builder OS

Wave 3 Build OS. Construct working software carefully — construction plans, reviews, safe refactors, legacy seams — not hero rewrites.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (32 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: research-os, evaluation-os.
