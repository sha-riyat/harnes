# Example: retry-seam

Blob: SendService with static SMS client. Needed: retry. Characterization: current send outcomes. Seam: wrap client. Sprout RetryingClient. Tests on retry policy. Diff: wrap only, no template rewrite.
