# First principles — builder-os

1. Construction makes change cheap and behavior obvious.
2. Names, seams, and tests are design.
3. Legacy is code without tests you trust; add them before sermons.
4. Patterns are vocabulary, not a checklist religion.
5. Debugging is a protocol.
6. Evidence about software (Making Software) beats folklore.
7. Language guides are local law, not universal craft.
8. Staff-plus work is still construction plus leverage.
9. No promised 10x from a clean-code identity.
10. Anti-guru: no style-war OS.
