# Seam

A boundary you can intercept. Enable tests, then change.
