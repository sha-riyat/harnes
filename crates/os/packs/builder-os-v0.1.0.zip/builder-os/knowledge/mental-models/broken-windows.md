# Broken windows

Visible rot becomes permitted rot. Repair small, often.
