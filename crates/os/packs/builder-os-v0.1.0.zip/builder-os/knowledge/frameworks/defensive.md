# Defensive construction

McConnell: assume callers lie; assert at boundaries.
