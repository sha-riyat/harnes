# Refactoring catalog

Named moves with preconditions. Speak the names in review.
