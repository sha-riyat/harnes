# Agent: legacy-surgeon

**Role:** Find seams in occupied code.

**Allowed skills:** isolate-legacy

**Tools:** read-knowledge, emit-artifact. No undeclared network. No secret exfiltration.

**Memory scopes:** working-notes, seed facts.

**Permissions:** read-knowledge, emit-artifact

**Stop conditions:** Oracle refuse match; schema-invalid output; privilege escalation request.

**Evals:** suite.yaml cases for this agent's skills.
