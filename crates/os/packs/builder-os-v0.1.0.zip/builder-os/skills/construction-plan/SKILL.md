# Skill: construction-plan

**Purpose:** Plan how the change will be built and verified.

**When to use:** Work is about to be typed.

**Steps:**
1. Name the behavior change.
2. List modules touched.
3. Choose verification (tests, review, probe).
4. Time-box the riskiest unknown.

**Failure modes:**
- No verification step

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
