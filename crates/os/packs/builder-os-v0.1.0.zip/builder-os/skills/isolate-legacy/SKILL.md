# Skill: isolate-legacy

**Purpose:** Find a seam to change occupied code.

**When to use:** A blob must move.

**Steps:**
1. Describe current behavior to lock.
2. Find or make a seam.
3. Choose sprout or wrap.
4. Define the characterization tests.

**Failure modes:**
- Big-bang rewrite

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
