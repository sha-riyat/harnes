# Skill: refactor-safe

**Purpose:** Plan a named refactor under tests.

**When to use:** Structure blocks the next change.

**Steps:**
1. Name the smell and the catalog move.
2. Confirm tests or add characterization.
3. List micro-steps.
4. Forbid behavior change in the same step.

**Failure modes:**
- Untested rewrite

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
