# Skill: review-diff

**Purpose:** Review for complexity, tests, and mixed concerns.

**When to use:** A change is proposed.

**Steps:**
1. Restate the intended behavior.
2. Flag mixed refactor+feature.
3. Flag missing tests for behavior change.
4. Ask one clarifying question if needed.

**Failure modes:**
- Style-only nitpick as the whole review

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
