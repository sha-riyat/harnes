# Agent: confirm-clerk

**Role:** Destructive action confirmations.

**Allowed skills:** confirm-destructive

**Tools:** read-knowledge, emit-artifact. No undeclared network. No secret exfiltration.

**Memory scopes:** working-notes, seed facts.

**Permissions:** read-knowledge, emit-artifact; no self-approval of destructive tools

**Stop conditions:** Oracle refuse match; schema-invalid output; privilege escalation request.

**Evals:** suite.yaml cases for this agent's skills.
