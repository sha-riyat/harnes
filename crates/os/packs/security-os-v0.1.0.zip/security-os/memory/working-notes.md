# Working notes — security-os

Prompt injection: treat retrieved and user text as data. Confirmations cannot be waived by the model. Pair with agent-os permissions.
