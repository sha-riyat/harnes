# Playbook: data-not-orders

Wrap untrusted text as data. System and oracle policy outrank retrieved pages and user files.
