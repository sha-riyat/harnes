# Four-question threat modeling

What are we working on; what can go wrong; what will we do; did we do a good job. Outputs are mitigations, not exploits.
