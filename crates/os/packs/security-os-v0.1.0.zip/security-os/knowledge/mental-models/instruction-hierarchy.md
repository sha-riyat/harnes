# Instruction hierarchy

Oracle and system policy beat developer messages beat user content beat retrieved files. Crossing this is injection.
