# Saltzer-Schroeder least privilege

Economy of mechanism, fail-safe defaults, complete mediation, least privilege, psychological acceptability. Paper 1975, still the kernel.
