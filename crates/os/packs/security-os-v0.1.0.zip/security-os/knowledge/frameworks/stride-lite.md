# STRIDE as mnemonic

Use as a checklist of failure classes, never as an attack tutorial.
