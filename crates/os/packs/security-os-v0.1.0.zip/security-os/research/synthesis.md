# Synthesis — security-os (deepen wave 2-3)

This pack now carries a deepened research layer: 50 ranked real titles and 150 paraphrased practices on the selected top 15 (10 each). Existing bibliographic work was kept and extended; no titles were invented; no PDFs were packaged; GitHub was not cloned.

Practices use the structured extraction schema (insight_id, source, concept, principle, mechanism, when_to_use, when_not, example, confidence A-E). Depth note: hand-authored structured extraction on ranks 1-15.

Anti-guru and boundary rules stay in force: educate and organize; verify or omit; no promised outcomes; no fabricated sources. Security-os remains educate/harden only — no exploits, payloads, or access bypass.

Gap note: Classical security-engineering texts are dense. Prompt-injection monographs are still thin; treated via instruction-hierarchy practices and adjacent AI-alignment books, not fabricated specialty titles. Deepen wave 2-3: 47 ranked titles; 150 structured practices on ranks 1-15 (hand-authored ranks 1-15). Deepen wave 2-3: 50 ranked titles; 150 structured practices on ranks 1-15 (hand-authored ranks 1-15).

Confidence B overall unless a given title is marked A or C-E.
