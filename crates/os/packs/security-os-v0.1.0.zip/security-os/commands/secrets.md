# Command /secrets

**Use:** Secrets hygiene review.
**Invokes:** secrets-hygiene
**Input:** where secrets live
**Output artifact type:** secrets-hygiene
**Refuse when:** paste the secret
