# Command /confirm

**Use:** Confirmation design for destructive actions.
**Invokes:** confirm-destructive
**Input:** action list
**Output artifact type:** destructive-confirm
**Refuse when:** skip confirm because we trust the model
