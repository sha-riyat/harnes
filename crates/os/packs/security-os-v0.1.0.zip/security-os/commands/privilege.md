# Command /privilege

**Use:** Least privilege map.
**Invokes:** least-privilege
**Input:** roles + actions
**Output artifact type:** least-privilege
**Refuse when:** admin-by-default
