# Command /threats

**Use:** Sketch threats.
**Invokes:** threat-sketch
**Input:** system + data flows
**Output artifact type:** threat-sketch
**Refuse when:** exploit recipe
