# hermes adapter — security-os

Purpose of this OS: Least privilege, instruction hierarchy, secrets hygiene, and confirmation for destructive actions — operational security engineering, not a legal opinion and not an exploit manual.

## Mapping
Use Hermes tool-call XML or JSON as the host requires. Bind one skill per turn unless a workflow is explicit. Unsupported: native multi-agent runtime.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Stub contract only. Not a live client. No copyrighted book ingest.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
