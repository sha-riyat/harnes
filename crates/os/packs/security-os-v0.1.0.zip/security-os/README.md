# Security OS

Wave 3 Build OS. Least privilege, instruction hierarchy, secrets hygiene, and confirmation for destructive actions — operational security engineering, not a legal opinion and not an exploit manual.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (32 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: agent-os, evaluation-os.
