# Skill: threat-sketch

**Purpose:** Sketch what can go wrong at trust boundaries, including prompts.

**When to use:** A system or agent tool list is changing.

**Steps:**
1. Draw data flows and trust boundaries.
2. List classes of what can go wrong (spoof, tamper, repudiate, info leak, deny, elevate, inject-instructions).
3. Map mitigations as work items.
4. Strip any exploit how-to from the output.

**Failure modes:**
- Attack cookbook output

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
