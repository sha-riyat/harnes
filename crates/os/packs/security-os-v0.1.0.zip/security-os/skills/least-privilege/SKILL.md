# Skill: least-privilege

**Purpose:** Grant the minimum authority for the stated job.

**When to use:** Roles or agent tools are being defined.

**Steps:**
1. List actions.
2. Map each to a principal.
3. Remove unused authority.
4. Define breakglass with audit and expiry.

**Failure modes:**
- Shared admin as the model

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
