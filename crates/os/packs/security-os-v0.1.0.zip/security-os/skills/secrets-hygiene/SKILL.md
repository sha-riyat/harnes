# Skill: secrets-hygiene

**Purpose:** Keep secrets out of repos, logs, chats, and model context.

**When to use:** A credential or key is in play.

**Steps:**
1. Classify the secret.
2. Name allowed stores.
3. Forbid prompt/log/repo placement.
4. Define rotation and revocation.

**Failure modes:**
- Ask the user to paste the live secret into chat

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
