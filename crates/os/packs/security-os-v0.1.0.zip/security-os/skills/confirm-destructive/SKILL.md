# Skill: confirm-destructive

**Purpose:** Require typed confirmation for high-impact actions.

**When to use:** Delete, pay, share-secret, prod-mutate, mass-message.

**Steps:**
1. List high-impact actions.
2. Require an out-of-band or typed confirm by a named principal.
3. No model self-approval.
4. Log the confirmation without logging secrets.

**Failure modes:**
- Trust-the-agent skip

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
