# Skill: specify-interaction

**Purpose:** Specify controls, feedback, and error prevention.

**When to use:** Implementation needs a contract.

**Steps:**
1. Name posture and platform conventions.
2. Specify happy path feedback.
3. Specify illegal-state prevention.
4. List accessibility obligations.

**Failure modes:**
- Spec as mock-only

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
