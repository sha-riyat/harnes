# Skill: frame-job

**Purpose:** Frame the job, pains, and success signal.

**When to use:** A screen list exists without a job.

**Steps:**
1. Name the role and context of use.
2. Write the job in the person's language.
3. List failure costs.
4. Name one success signal.

**Failure modes:**
- Feature-first frame

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
