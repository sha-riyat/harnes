# Skill: run-usability-lite

**Purpose:** Plan a three-to-five person think-aloud.

**When to use:** You need evidence, not opinions in a meeting.

**Steps:**
1. Write tasks.
2. Recruit from the role, not the office.
3. Define notes template.
4. Define the decision the test can change.

**Failure modes:**
- Demo disguised as a test

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
