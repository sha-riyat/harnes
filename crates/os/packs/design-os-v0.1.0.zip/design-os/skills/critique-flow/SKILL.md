# Skill: critique-flow

**Purpose:** Critique a user path for thinking-cost and wayfinding.

**When to use:** A flow is about to be built or shipped.

**Steps:**
1. State the task.
2. Walk the steps as a scanner, not a novelist.
3. Mark think-points and dead ends.
4. Offer a thinner path.

**Failure modes:**
- No task stated

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
