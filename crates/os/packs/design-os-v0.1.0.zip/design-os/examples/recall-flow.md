# Example: recall-flow

Job: front-desk fills chairs tomorrow. Flow critique: three screens of marketing copy before the date picker is excise. Spec: date, slot, confirm, SMS preview. Lite test: three receptionists, task 'schedule a missed hygiene recall', decision = keep or cut the marketing screen.
