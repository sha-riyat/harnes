# Working notes — design-os

Hand prototypes to prototype-os. Hand interviews that are discovery (not usability) to customer-discovery-os.
