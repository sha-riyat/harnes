# Playbook: stress-case

Include at least one stress case (tired, error, low bandwidth, crisis) from Design for Real Life.
