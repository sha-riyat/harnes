# Playbook: think-aloud-not-demo

If you are selling the design during the session, you are not testing.
