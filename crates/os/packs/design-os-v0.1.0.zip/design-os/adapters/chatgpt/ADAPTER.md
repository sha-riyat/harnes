# chatgpt adapter — design-os

Purpose of this OS: Shape usable, ethical product experiences from goals and constraints — flows, interaction specs, and cheap usability — not dribbble shots.

## Mapping
Function/tool calling with output.schema.json as the parameters schema. Oracle refuse before any function that mutates.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Stub contract only. Not a live client. No copyrighted book ingest.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
