# Command /job

**Use:** Frame the user job.
**Invokes:** frame-job
**Input:** context
**Output artifact type:** job-frame
**Refuse when:** feature-first framing
