# Command /flow

**Use:** Critique a path.
**Invokes:** critique-flow
**Input:** screens or steps
**Output artifact type:** flow-critique
**Refuse when:** no task
