# Command /ixd

**Use:** Specify interaction.
**Invokes:** specify-interaction
**Input:** goal + platform
**Output artifact type:** interaction-spec
**Refuse when:** excise-heavy
