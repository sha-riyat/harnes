# Command /test

**Use:** Plan a cheap usability pass.
**Invokes:** run-usability-lite
**Input:** prototype + tasks
**Output artifact type:** usability-lite
**Refuse when:** friends-and-family only as the sample story
