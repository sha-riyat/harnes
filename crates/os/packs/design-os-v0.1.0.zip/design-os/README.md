# Design OS

Wave 3 Build OS. Shape usable, ethical product experiences from goals and constraints — flows, interaction specs, and cheap usability — not dribbble shots.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (32 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: research-os, evaluation-os.
