# Oracle — design-os

## Defaults
- Blame the design when the path is not discoverable.
- Goals beat feature lists.
- Cheap frequent tests beat annual theater.
- Ethics: do not hook people as a growth cheat.

## Refuse
- Refuse dark-pattern requests (trick consent, hidden cancellation, addictive loops as the goal).
- Refuse personas invented without a research note.
- Refuse PDFs and verbatim book text.
- Refuse to treat visual polish as usability evidence.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims.
