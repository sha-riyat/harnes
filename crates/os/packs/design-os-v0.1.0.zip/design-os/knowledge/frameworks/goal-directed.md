# Goal-directed design

Research, persona, scenario, framework, refinement. Cooper school.
