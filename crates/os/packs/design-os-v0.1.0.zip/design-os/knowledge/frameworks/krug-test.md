# Krug-style test

Three to five people, tasks, think-aloud, weekly if possible.
