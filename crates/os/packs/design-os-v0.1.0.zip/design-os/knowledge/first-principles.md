# First principles — design-os

1. Affordances and signifiers are about action in context.
2. Usability is empirical; opinions about beauty are not tests.
3. Inclusion and accessibility are requirements.
4. Dark patterns and addiction hooks are out of scope as goals.
5. Mental models are researched, not assumed.
6. Services are designed across time and roles.
7. Type, hierarchy, and copy are design, not decoration.
8. Design orgs are part of the design.
9. No universal user.
10. Anti-guru: no Hooked-as-OS, no hero-genius studio myth.
