# Gulfs of execution and evaluation

Can I do it; can I tell it worked. Design shrinks both gulfs.
