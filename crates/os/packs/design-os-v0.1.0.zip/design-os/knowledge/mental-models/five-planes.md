# Five planes

Strategy, scope, structure, skeleton, surface. Do not paint the surface first.
