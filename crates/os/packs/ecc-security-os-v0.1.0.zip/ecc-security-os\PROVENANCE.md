# Provenance

- Source: https://github.com/affaan-m/ECC
- License: MIT (see LICENSE-ECC)
- Pinned commit: 90606c8315ee09cafc303515c5f33024db6b9882
- Upstream author: Affaan Mustafa
- Selection: 9 skills, curated for harnes; not the full ECC catalogue.

## Copied verbatim
- skills/security-review/
- skills/security-scan/
- skills/security-bounty-hunter/
- skills/agent-security-hardening/
- skills/mcp-dependency-review/
- skills/hookify-rules/
- skills/gateguard/
- skills/operator-approval-loop/
- skills/safety-guard/

## harnes wrappers

manifest.yaml, OS.md, oracle/ORACLE.md, routing/intents.yaml, playbooks/, rules/, agents/, NOTICE and this file were written for harnes. They do not modify the copied skills.
