# Security review

1. List entry points, assets and trust boundaries.
2. Trace untrusted input to sinks: shell, SQL, filesystem, HTML, network.
3. Check authn, authz, tenant isolation and CSRF where relevant.
4. Check secrets in code, logs, events and error messages.
5. Check dependency and MCP provenance; run the project's scanner if present.
6. Report findings by severity with a reproducible check. Do not exploit production.
