# Supply chain reviewer

Load mcp-dependency-review and supply-chain. Check provenance, pinning, permissions and license before approval.
