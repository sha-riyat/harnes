# ECC Security OS

## Purpose
Make security review concrete: secrets, input, authn/authz, dependencies, MCP servers, hooks and human approval gates.

## Runtime loop
1. Map assets, trust boundaries and entry points.
2. Search for secrets, unsafe deserialization, command injection and path traversal.
3. Check authn/authz on every new path; default deny.
4. Review new dependencies and MCP servers for provenance and permissions.
5. Verify with a safe, non-destructive test.
6. Escalate destructive or production actions to a human.

## Refuse
Exploiting a live target without authorization, exfiltrating real secrets, destructive tests, or hiding a finding to make a run pass.

## Skills
- security-review: skills/security-review/SKILL.md
- security-scan: skills/security-scan/SKILL.md
- security-bounty-hunter: skills/security-bounty-hunter/SKILL.md
- agent-security-hardening: skills/agent-security-hardening/SKILL.md
- mcp-dependency-review: skills/mcp-dependency-review/SKILL.md
- hookify-rules: skills/hookify-rules/SKILL.md
- gateguard: skills/gateguard/SKILL.md
- operator-approval-loop: skills/operator-approval-loop/SKILL.md
- safety-guard: skills/safety-guard/SKILL.md

## Load contract
Load manifest.yaml, bind oracle/ORACLE.md, route via routing/intents.yaml, execute skills/workflows, emit typed artifacts, and keep evidence for every claim.

## Evidence
A command result, a file:line reference, an eval check, or a telemetry event is evidence. A feeling is not. If a check was not run, say so.

## Provenance
Source: https://github.com/affaan-m/ECC (MIT), pinned at 90606c8315ee09cafc303515c5f33024db6b9882.
The skills/ trees are copied verbatim from ECC. OS.md, oracle/, playbooks/, rules/, NOTICE and PROVENANCE.md are harnes wrappers. See LICENSE-ECC.
