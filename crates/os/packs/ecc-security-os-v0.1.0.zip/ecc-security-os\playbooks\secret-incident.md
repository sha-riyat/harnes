# Secret incident

1. Stop using the value; do not paste it into chat or a report.
2. Identify where it was written: file, log, event, commit, cache.
3. Redact and rotate through the owning system; a human performs rotation.
4. Remove the value from artifacts and history where feasible.
5. Add a guard rule so the same path is denied next time.
6. Record only the redacted evidence and the rotation status.
