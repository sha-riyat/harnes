# Secret handling

Never emit a real token, key or password in a summary, event, report or commit. Use the telemetry redactor and the guards. If a secret is found, stop and follow playbooks/secret-incident.md.
