# Oracle â€” ECC Security OS

## Non-negotiables
- Never print, commit or transmit a real secret. Redact first.
- Deny by default; grant the minimum permission.
- A security finding needs a concrete path, impact and evidence.
- Destructive or production actions require explicit human approval.
- Do not add a dependency or MCP server with unknown provenance.

## Attribution

ECC is MIT-licensed. Keep LICENSE-ECC, NOTICE and PROVENANCE.md with the pack. Do not relicense ECC content.
