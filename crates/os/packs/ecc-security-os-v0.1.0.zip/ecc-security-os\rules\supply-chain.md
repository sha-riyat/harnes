# Supply chain

A new dependency or MCP server needs a pinned version, a source URL, a license and a reason. Unknown provenance is denied, not assumed safe.
