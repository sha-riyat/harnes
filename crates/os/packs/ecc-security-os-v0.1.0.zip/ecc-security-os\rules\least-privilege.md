# Least privilege

Every tool and MCP server gets the narrowest root and the fewest capabilities that work. A write outside the project root is denied unless a human approves it for one action.
