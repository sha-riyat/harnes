# MCP supply chain review

1. Identify the server, version, source repository and command.
2. Check what filesystem, network and credentials it can reach.
3. Prefer pinned versions and least-privilege roots.
4. Review the tool list for dangerous capabilities: shell, write, publish.
5. Deny unknown or unpinned servers in the guard policy.
6. Record the provenance and the decision.
