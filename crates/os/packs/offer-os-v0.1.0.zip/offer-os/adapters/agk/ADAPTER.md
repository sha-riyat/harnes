# agk adapter — offer-os

Purpose of this OS: Design a bounded promise: jobs, fit, packaging, and kill tests — not a feature dump or an irresistible-template.

## Mapping
Map skills to AGK tool names. Keep oracle refuse as a pre-tool gate. Do not grant filesystem or network beyond the agent permission list.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Stub contract only. Not a live client. No copyrighted book ingest.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
