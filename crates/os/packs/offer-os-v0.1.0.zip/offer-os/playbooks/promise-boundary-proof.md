# Playbook: promise-boundary-proof

Every offer artifact has a promise, a boundary, and a proof or a gap.
