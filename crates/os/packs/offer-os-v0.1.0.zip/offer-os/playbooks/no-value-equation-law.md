# Playbook: no-value-equation-law

Popular value-equation posts are rhetoric. Use WTP research in pricing-os.
