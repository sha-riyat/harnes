# First principles — offer-os

1. An offer is a valued outcome in a circumstance, packaged and priced.
2. Jobs and outcomes beat feature lists.
3. Alternatives include do-nothing and incumbents the buyer already uses.
4. A canvas is a hypothesis sheet, not a company.
5. Price architecture is part of the offer.
6. Compliments are not evidence; commitment is.
7. Kill is a first-class decision.
8. Public and regulated offers exist; do not pretend only VC canvases do.
9. No promised product-market-fit date or $100M from a formula.
10. Anti-guru: no Hormozi carnival as method.
