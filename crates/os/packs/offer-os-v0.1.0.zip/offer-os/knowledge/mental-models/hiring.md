# Hiring and firing

Christensen: offers get hired for progress and fired for struggle.
