# Proposition fit

Osterwalder: testable cells, not balanced decoration.
