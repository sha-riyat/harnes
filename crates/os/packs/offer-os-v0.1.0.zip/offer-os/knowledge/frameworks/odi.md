# Outcome-driven innovation

Ulwick: importance vs satisfaction on outcomes.
