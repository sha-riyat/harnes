# Pretotype

Savoia: test the idea of the offer before the product of the offer.
