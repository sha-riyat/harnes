# Offer OS

Wave 4 Grow OS. Design a bounded promise: jobs, fit, packaging, and kill tests — not a feature dump or an irresistible-template.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (28 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: positioning-os, business-model-os, customer-discovery-os.
