# Working notes — offer-os

Feeds pricing-os, sales-os, content-os. Discovery evidence from customer-discovery-os.
