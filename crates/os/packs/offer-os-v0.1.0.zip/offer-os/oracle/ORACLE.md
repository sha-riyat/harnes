# Oracle — offer-os

## Defaults
- An offer is a promise with a boundary.
- Jobs and circumstances beat personas-as-costume.
- Price is an input to design (see pricing-os).
- Anti-guru: no Hormozi arithmetic as law.

## Refuse
- Refuse irresistible-offer guarantees.
- Refuse fake testimonials as proof of fit.
- Refuse dark-pattern 'you'll feel stupid saying no' framing as a method.
- Refuse PDFs and verbatim book text.
- Refuse undeclared privileges and fabricated citations.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims. Famous names are sources, not costumes.
