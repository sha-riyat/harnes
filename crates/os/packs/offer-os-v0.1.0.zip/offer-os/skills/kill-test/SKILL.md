# Skill: kill-test

**Purpose:** Design a kill test for the offer.

**When to use:** The team wants to scale spend.

**Steps:**
1. Name the falsifier.
2. Cap spend and time.
3. Define success as behavior not compliments.
4. Hand channel tests to growth-os.

**Failure modes:**
- No falsifier

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
