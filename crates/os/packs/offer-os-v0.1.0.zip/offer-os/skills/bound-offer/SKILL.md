# Skill: bound-offer

**Purpose:** Bound the promise: included, excluded, proof.

**When to use:** Sales customizes a new product every call.

**Steps:**
1. Write the promise in buyer language.
2. List exclusions.
3. Attach proof or proof-gap.
4. Name packaging tiers only if segments differ.

**Failure modes:**
- Feature dump

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
