# Skill: score-fit

**Purpose:** Score proposition fit and holes.

**When to use:** A canvas is filled with slogans.

**Steps:**
1. Jobs pains gains vs relievers creators.
2. Mark untested cells.
3. Rank importance.
4. Name one test.

**Failure modes:**
- Pretty-canvas-as-fit

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
