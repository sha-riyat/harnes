# Skill: spec-job

**Purpose:** Write the job and circumstance the offer is hired for.

**When to use:** Features exist without a job.

**Steps:**
1. Name progress sought.
2. Name circumstance and competitors including non-consumption.
3. List firing conditions.
4. State evidence source.

**Failure modes:**
- Persona costume as job

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
