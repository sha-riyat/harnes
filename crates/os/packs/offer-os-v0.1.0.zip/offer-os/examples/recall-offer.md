# Example: recall-offer

Job: practice manager reducing no-shows without spamming patients. Promise: protocol-tied reminders with confirmation. Exclusion: not a marketing blast tool. Proof gap: one clinic cohort. Kill: if buyers will only buy a generic SMS bundle on price.
