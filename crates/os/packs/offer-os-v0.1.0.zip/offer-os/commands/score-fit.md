# Command /score-fit

**Use:** Score proposition fit and holes.
**Invokes:** score-fit
**Input:** canvas
**Output artifact type:** score-fit-artifact
**Refuse when:** Pretty-canvas-as-fit
