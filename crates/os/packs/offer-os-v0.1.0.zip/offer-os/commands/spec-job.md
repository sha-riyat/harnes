# Command /spec-job

**Use:** Write the job and circumstance the offer is hired for.
**Invokes:** spec-job
**Input:** context
**Output artifact type:** spec-job-artifact
**Refuse when:** Persona costume as job
