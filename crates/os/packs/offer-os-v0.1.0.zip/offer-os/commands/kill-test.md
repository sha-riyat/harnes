# Command /kill-test

**Use:** Design a kill test for the offer.
**Invokes:** kill-test
**Input:** offer
**Output artifact type:** kill-test-artifact
**Refuse when:** No falsifier
