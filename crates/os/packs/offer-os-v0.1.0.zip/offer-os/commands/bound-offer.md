# Command /bound-offer

**Use:** Bound the promise: included, excluded, proof.
**Invokes:** bound-offer
**Input:** promise
**Output artifact type:** bound-offer-artifact
**Refuse when:** Feature dump
