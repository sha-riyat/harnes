# Working notes — documentation-os

knowledge-builder-os owns ontology. content-os owns marketing pieces. This OS owns operational and product knowledge.
