# Documentation OS

## Purpose
Make knowledge findable and maintainable for a named reader job — not wiki sprawl, fake completeness, or trophy docs.

## Load contract
Load manifest.yaml, bind oracle/ORACLE.md, route via routing/intents.yaml, execute skills/workflows, emit typed artifacts, score with evals/.

## Runtime loop
1. Bind oracle/ORACLE.md as non-overridable policy.
2. Route via routing/intents.yaml.
3. Assemble context with context-memory rules (or local policy if that OS is not loaded).
4. Execute skill or workflow; emit a typed artifact.
5. Score with evals/suite.yaml before promoting memory.

## Quality gate
Overall quality target 90/100. No category below 7. Linter must pass. No unfinished stub markers.

## Refuse
Oracle refuse rules, unverified bibliographic invention, PDF/book-text ingest, undeclared privileges.

## Non-goals
This OS does not replace professional judgment in licensed domains. It does not ship copyrighted books or PDFs. It does not ship copyrighted manuals. It does not guarantee rankings.
