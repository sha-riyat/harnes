# Skill: design-ia

**Purpose:** Design organization, labels, navigation, and search.

**When to use:** People cannot find the page that exists.

**Steps:**
1. Label in the reader's language.
2. Separate tutorial, how-to, reference, explanation.
3. Plan search fallbacks.
4. Test with a tree test or equivalent.

**Failure modes:**
- Pretty theme as IA

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
