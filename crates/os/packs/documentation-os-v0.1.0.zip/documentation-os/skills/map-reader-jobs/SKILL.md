# Skill: map-reader-jobs

**Purpose:** Map the jobs readers hire the docs to do.

**When to use:** A wiki is organized by team names.

**Steps:**
1. List tasks, concepts, reference needs, and learning paths.
2. Name the arrival context (search, link, onboarding).
3. Drop diary pages.
4. Assign owners.

**Failure modes:**
- Org-chart as IA

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
