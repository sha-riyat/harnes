# Skill: brief-topic

**Purpose:** Brief a topic that can stand as page one.

**When to use:** A chapter that requires the whole manual.

**Steps:**
1. State the job.
2. State type.
3. Link, do not preamble forever.
4. List the truth source.

**Failure modes:**
- Novel chapter as a topic

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
