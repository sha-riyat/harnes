# Skill: set-docs-ops

**Purpose:** Set the docs-as-code bar: review, test, publish, measure.

**When to use:** Docs lag the product by months.

**Steps:**
1. Same cadence as code when behavior changes.
2. Lint and review.
3. Measure task success, not only views.
4. Name an owner for AI-assisted drafts.

**Failure modes:**
- Publish-and-forget

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
