# Playbook: page-one

If a search landing cannot complete a job, it is not done.
