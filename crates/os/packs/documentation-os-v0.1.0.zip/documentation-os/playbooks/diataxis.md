# Playbook: diataxis

Do not mix tutorial and reference on one page without a reason. Procida's Diataxis is the public map.
