# Documentation OS

Wave 5 Operate OS. Make knowledge findable and maintainable for a named reader job — not wiki sprawl, fake completeness, or trophy docs.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (27 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: knowledge-builder-os, evaluation-os.
