# Synthesis — documentation-os (deepen wave 4-5)

This pack now carries a deepened research layer: 38 ranked real titles and 150 paraphrased practices on the selected top 15 (10 each). Existing bibliographic work was kept and extended; no titles were invented; no PDFs were packaged; GitHub was not cloned.

Practices use the structured extraction schema (insight_id, source, concept, principle, mechanism, when_to_use, when_not, example, confidence A-E). Depth note: structured extraction: existing one-liners preserved as principles where present; remaining selected ranks expanded with book-titled operator moves (schema-fill).

Anti-guru and money boundaries stay in force: educate and organize; verify or omit; no promised revenue, growth, quota, or virality; no fabricated sources; no dark-pattern methods.

Gap note: Tech-comm and IA books are dense. Diataxis is a public web framework, cited in synthesis, not ranked as a book. Deepen wave 4-5: 28 ranked titles; 150 structured practices on ranks 1-15 (schema-fill on selected ranks (existing one-liners kept)). Deepen wave 4-5: 38 ranked titles; 150 structured practices on ranks 1-15 (schema-fill on selected ranks (existing one-liners kept)).

Confidence B overall unless a given title is marked A or C-E.
