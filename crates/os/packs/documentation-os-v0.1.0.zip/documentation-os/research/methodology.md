# Research methodology — documentation-os

Questions: which books in this domain are real, publisher-checkable, and usable by an operator? which titles overclaim money or identity?

Method: keep the existing verified ranked list; add only titles with checkable author, year, and publisher; omit if uncertain. Paraphrase practices. Grade A-E. No PDFs. No fabricated books. No GitHub clone.

Deepen wave 4-5: target about 50 real books; 10 paraphrased practices on each of ranks 1-15; refresh first principles, contradictions, and ontology from the extraction.

Exclusions: guru merch as methods; success or revenue guarantees; invented citations; dark-pattern or wolf-energy readings; personalized financial advice as fact.
