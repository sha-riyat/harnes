# IA stack

Rosenfeld/Morville/Arango: org, label, nav, search.
