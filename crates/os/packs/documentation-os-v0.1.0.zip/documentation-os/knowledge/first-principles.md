# First principles — documentation-os

1. Every page is for a reader with a job; piles are not docs.
2. Topic-based writing and IA beat a novel that nobody can find.
3. Docs-like-code is a workflow, not a religion.
4. Style guides create consistency; they do not create findability.
5. Living documentation hooks to the system that changes.
6. Architecture views need viewpoints and legends.
7. Deprecation is a first-class act.
8. Fake completeness is a catalog crime.
9. No promised adoption from a pretty theme.
10. Anti-guru: no wiki dump; no Elements-of-Style as an IA.
