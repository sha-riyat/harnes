# Four doc types

Tutorial, how-to, reference, explanation — popularized as Diataxis by Daniele Procida (web, not a book).
