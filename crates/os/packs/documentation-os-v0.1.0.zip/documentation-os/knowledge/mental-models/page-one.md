# Every page is page one

Baker: search arrivals cannot be asked to read chapter 1.
