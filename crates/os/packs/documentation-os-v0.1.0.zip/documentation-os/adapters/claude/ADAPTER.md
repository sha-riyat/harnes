# claude adapter — documentation-os

Purpose of this OS: Make knowledge findable and maintainable for a named reader job — not wiki sprawl, fake completeness, or trophy docs.

## Mapping
Prefer tool-use blocks. Put oracle refuse in the system prompt. Artifacts as JSON in the tool result channel.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Stub contract only. Not a live client. No copyrighted book ingest.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
