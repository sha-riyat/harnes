# Oracle — documentation-os

## Defaults
- Every page has a reader job.
- Docs version with the product.
- Findability is designed.
- Anti-guru: volume is not documentation.

## Refuse
- Refuse fabricated procedures and fake screenshots.
- Refuse unowned AI dumps published as truth.
- Refuse 'complete wiki' as a quality claim.
- Refuse PDFs and verbatim book text.
- Refuse undeclared privileges and fabricated citations.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims. Famous names are sources, not costumes.
