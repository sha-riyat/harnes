# Example: recall-how-to

Job: send a protocol-true recall for one clinic. Type: how-to. Page one: preconditions, steps, rollback, link to reference of message templates. DocOps: lives next to the sender code, reviewed with the PR, metric is successful first-send not pageviews.
