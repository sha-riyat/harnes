# Command /brief-topic

**Use:** Brief a topic that can stand as page one.
**Invokes:** brief-topic
**Input:** job
**Output artifact type:** brief-topic-artifact
**Refuse when:** Novel chapter as a topic
