# Command /set-docs-ops

**Use:** Set the docs-as-code bar: review, test, publish, measure.
**Invokes:** set-docs-ops
**Input:** repo
**Output artifact type:** set-docs-ops-artifact
**Refuse when:** Publish-and-forget
