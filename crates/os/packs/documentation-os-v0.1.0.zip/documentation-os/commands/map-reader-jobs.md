# Command /map-reader-jobs

**Use:** Map the jobs readers hire the docs to do.
**Invokes:** map-reader-jobs
**Input:** product
**Output artifact type:** map-reader-jobs-artifact
**Refuse when:** Org-chart as IA
