# Command /design-ia

**Use:** Design organization, labels, navigation, and search.
**Invokes:** design-ia
**Input:** jobs
**Output artifact type:** design-ia-artifact
**Refuse when:** Pretty theme as IA
