# Pricing OS

Wave 4 Grow OS. Design value-based price architecture: metrics, fences, versions, and ethics — not cost-plus folklore or fake scarcity.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (28 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: offer-os, evaluation-os.
