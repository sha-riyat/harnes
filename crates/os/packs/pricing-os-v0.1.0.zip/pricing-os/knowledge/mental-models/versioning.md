# Versioning

Shapiro/Varian: let segments self-select without pretending one price fits.
