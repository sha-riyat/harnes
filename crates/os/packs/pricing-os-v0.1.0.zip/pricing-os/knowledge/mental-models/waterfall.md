# Pocket-price waterfall

Marn et al.: on-invoice and off-invoice leakages.
