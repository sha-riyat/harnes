# First principles — pricing-os

1. Price is policy and communication, not leftover cost-plus.
2. Structure, fences, and metrics matter more than a single number.
3. Willingness to pay is researched, not guessed in a war room only.
4. Behavioral reference prices exist; they are not a license to trick.
5. Versioning and RM are for capacity and segments you can actually fence.
6. Discount leakage is an operating system, not a salesperson personality.
7. Free is a model; name who pays.
8. Not personalized financial advice as fact.
9. No promised margin from a pricing book.
10. Anti-guru: no dark-pattern decoy as a virtue.
