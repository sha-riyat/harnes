# Value cascade

Nagle: economic value to perceived to WTP to price.
