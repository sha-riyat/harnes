# Playbook: value-then-number

No list price without a next-best alternative and a value driver list.
