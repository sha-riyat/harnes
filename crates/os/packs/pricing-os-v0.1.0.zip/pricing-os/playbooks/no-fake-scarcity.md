# Playbook: no-fake-scarcity

Countdown clocks that reset are deception, not pricing tactics.
