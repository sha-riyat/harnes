# Example: per-site

NBA: generic SMS plus staff time. Metric: per active clinic site per month, not per message (aligns to job). Versions: protocol pack vs blast pack. Fence: nonprofit clinics via ID. Discount: only annual prepay 8 percent, no 'because they asked'.
