# Working notes — pricing-os

Depends on offer-os. Revenue-os uses the architecture. Sales-os must not freelance the waterfall.
