# Command /sketch-value

**Use:** Sketch economic and perceived value with holes.
**Invokes:** sketch-value
**Input:** offer
**Output artifact type:** sketch-value-artifact
**Refuse when:** Cost-plus as the only story
