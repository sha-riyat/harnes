# Command /fence-segments

**Use:** Design fences so segments do not collapse.
**Invokes:** fence-segments
**Input:** segments
**Output artifact type:** fence-segments-artifact
**Refuse when:** Secret off-menu for anyone
