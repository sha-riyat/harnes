# Command /guard-discount

**Use:** Write a discount policy and say-no script.
**Invokes:** guard-discount
**Input:** policy_now
**Output artifact type:** guard-discount-artifact
**Refuse when:** Always-discount culture as strategy
