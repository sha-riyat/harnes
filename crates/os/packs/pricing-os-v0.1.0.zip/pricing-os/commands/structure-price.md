# Command /structure-price

**Use:** Propose metric, versioning, and list logic.
**Invokes:** structure-price
**Input:** value
**Output artifact type:** structure-price-artifact
**Refuse when:** Single unexplained number
