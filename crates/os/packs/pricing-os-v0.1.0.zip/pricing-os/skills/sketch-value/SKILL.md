# Skill: sketch-value

**Purpose:** Sketch economic and perceived value with holes.

**When to use:** A number is requested with no value story.

**Steps:**
1. Name the next-best alternative.
2. List value drivers.
3. Separate economic from perceived.
4. Mark research holes.

**Failure modes:**
- Cost-plus as the only story

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
