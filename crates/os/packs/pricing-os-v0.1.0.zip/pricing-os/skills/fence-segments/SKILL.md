# Skill: fence-segments

**Purpose:** Design fences so segments do not collapse.

**When to use:** Everyone asks for the same discount.

**Steps:**
1. Name segments by value, not by who shouts.
2. Choose fences (time, feature, ID, channel).
3. List leak paths.
4. Legal/ethics check.

**Failure modes:**
- Secret off-menu for anyone

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
