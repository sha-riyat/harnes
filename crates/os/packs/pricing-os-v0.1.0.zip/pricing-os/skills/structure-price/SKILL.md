# Skill: structure-price

**Purpose:** Propose metric, versioning, and list logic.

**When to use:** Packaging is a junk drawer.

**Steps:**
1. Choose the price metric.
2. Propose good/better/best only for real segments.
3. State list vs expected pocket.
4. Call out information-good versioning if relevant.

**Failure modes:**
- Single unexplained number

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
