# Skill: guard-discount

**Purpose:** Write a discount policy and say-no script.

**When to use:** Win-rates are bought with ad-hoc deals.

**Steps:**
1. State approved reasons to discount.
2. State forbidden reasons.
3. Align sales incentive notes.
4. Log expected waterfall leakage.

**Failure modes:**
- Always-discount culture as strategy

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
