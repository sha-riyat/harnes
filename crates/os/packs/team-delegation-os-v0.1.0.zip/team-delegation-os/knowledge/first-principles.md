# First principles — team-delegation-os

1. Output is of the team; managers produce through others (Grove).
2. Task-relevant maturity changes the mix of instruction and autonomy.
3. Intent-based leadership needs competence and clarity (Marquet).
4. Psychological safety is a condition for learning (Edmondson).
5. Multipliers give the problem; diminishers hoard it (Wiseman).
6. Adding people does not add the same communication structure (Brooks).
7. Coaching is questions plus a next experiment, not a TED talk.
8. Hiring and load design are part of delegation.
9. No promised high-performance from a poster.
10. Anti-guru: no Sinek/SEAL/Dare-to-Lead merch as an OS.
