# Task-relevant maturity

Grove: mix of instruction and autonomy follows the task, not the ego.
