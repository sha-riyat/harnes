# Leader-leader

Marquet: control, competence, clarity as a spiral.
