# Five dysfunctions as a checklist

Lencioni: use as conversation, not as a verdict on people.
