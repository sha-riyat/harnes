# Multiplier vs diminisher

Wiseman: who does the thinking; do not weaponize the label.
