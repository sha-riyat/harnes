# Playbook: intend

Replace 'request permission' with 'I intend to' plus constraints. If they cannot state intent, they are not ready.
