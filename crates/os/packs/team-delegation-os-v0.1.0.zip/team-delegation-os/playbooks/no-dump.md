# Playbook: no-dump

If you cannot name the output, you cannot delegate the output.
