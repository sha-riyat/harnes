# Example: intend-send

Decision: send the Tuesday cohort. TRM: nurse manager high on protocol, low on vendor API. Transfer: 'I intend to send Clinic A with the standard template; escalate if bounce >2 percent.' Health: last incident was reportable without blame. Review: manager no longer approves each message, still reviews exceptions weekly.
