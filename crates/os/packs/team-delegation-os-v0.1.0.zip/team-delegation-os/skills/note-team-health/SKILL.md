# Skill: note-team-health

**Purpose:** Note trust, conflict, and safety without a personality cult.

**When to use:** A fable pyramid is treated as a diagnosis.

**Steps:**
1. Edmondson: can bad news travel.
2. Lencioni: issue-conflict vs harmony.
3. Wiseman: who gets to think.
4. No public score of souls.

**Failure modes:**
- Five-dysfunctions poster as a HR file

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
