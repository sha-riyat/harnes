# Skill: transfer-control

**Purpose:** Transfer control with a visible intent.

**When to use:** People wait to be told.

**Steps:**
1. Marquet: I intend to.
2. Clarity of purpose and constraints.
3. Competence check.
4. How to escalate.

**Failure modes:**
- Abdication without constraints

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
