# Skill: review-delegation

**Purpose:** Review whether decisions actually moved.

**When to use:** Empowerment was announced.

**Steps:**
1. Count which decisions were made where.
2. Hero-manager remaining as bottleneck.
3. Candor incidents.
4. Adjust spec level.

**Failure modes:**
- Announcement as evidence

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
