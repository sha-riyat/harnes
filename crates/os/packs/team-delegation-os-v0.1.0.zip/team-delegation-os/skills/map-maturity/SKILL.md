# Skill: map-maturity

**Purpose:** Map task-relevant maturity for the decision.

**When to use:** The manager still approves every comma.

**Steps:**
1. Name the decision.
2. Grove: skill and knowledge for this task.
3. What would make tighter spec necessary.
4. Training gap.

**Failure modes:**
- One style for every task

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
