# generic-llm adapter — team-delegation-os

Purpose of this OS: Move decisions to the people with information, competence, and clarity — not abdication, hero-manager, or fake empowerment.

## Mapping
Pack SKILL.md + schemas + oracle excerpts into a single system block. Tools via JSON function-calling if the host supports it; otherwise ask the model to emit typed JSON matching output.schema.json.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Stub contract only. Not a live client. No copyrighted book ingest.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
