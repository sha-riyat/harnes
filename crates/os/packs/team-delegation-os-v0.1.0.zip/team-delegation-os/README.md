# Team Delegation OS

Wave 5 Operate OS. Move decisions to the people with information, competence, and clarity — not abdication, hero-manager, or fake empowerment.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (28 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: execution-os, evaluation-os.
