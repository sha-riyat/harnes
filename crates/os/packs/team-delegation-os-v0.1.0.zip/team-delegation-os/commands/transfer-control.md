# Command /transfer-control

**Use:** Transfer control with a visible intent.
**Invokes:** transfer-control
**Input:** maturity
**Output artifact type:** transfer-control-artifact
**Refuse when:** Abdication without constraints
