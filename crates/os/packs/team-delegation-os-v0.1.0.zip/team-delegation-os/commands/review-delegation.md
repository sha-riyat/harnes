# Command /review-delegation

**Use:** Review whether decisions actually moved.
**Invokes:** review-delegation
**Input:** period
**Output artifact type:** review-delegation-artifact
**Refuse when:** Announcement as evidence
