# Command /note-team-health

**Use:** Note trust, conflict, and safety without a personality cult.
**Invokes:** note-team-health
**Input:** team
**Output artifact type:** note-team-health-artifact
**Refuse when:** Five-dysfunctions poster as a HR file
