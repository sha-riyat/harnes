# Command /map-maturity

**Use:** Map task-relevant maturity for the decision.
**Invokes:** map-maturity
**Input:** decision
**Output artifact type:** map-maturity-artifact
**Refuse when:** One style for every task
