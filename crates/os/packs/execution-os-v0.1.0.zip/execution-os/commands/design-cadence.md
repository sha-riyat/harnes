# Command /design-cadence

**Use:** Design a weekly operating cadence.
**Invokes:** design-cadence
**Input:** goals
**Output artifact type:** design-cadence-artifact
**Refuse when:** More meetings as the cadence
