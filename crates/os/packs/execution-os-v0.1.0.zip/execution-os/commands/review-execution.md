# Command /review-execution

**Use:** Run an execution review that names reality.
**Invokes:** review-execution
**Input:** notes
**Output artifact type:** review-execution-artifact
**Refuse when:** Pep talk as review
