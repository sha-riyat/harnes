# Command /map-wip

**Use:** Map work in process and the actual constraint.
**Invokes:** map-wip
**Input:** system
**Output artifact type:** map-wip-artifact
**Refuse when:** A pretty board with hidden work
