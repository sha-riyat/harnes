# Command /set-leads

**Use:** Choose lead measures the team can influence.
**Invokes:** set-leads
**Input:** goal
**Output artifact type:** set-leads-artifact
**Refuse when:** Vanity as lead measure
