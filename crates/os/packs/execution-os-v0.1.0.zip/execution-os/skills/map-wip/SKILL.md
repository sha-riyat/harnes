# Skill: map-wip

**Purpose:** Map work in process and the actual constraint.

**When to use:** The team cannot say what is started, waiting, or done.

**Steps:**
1. List incoming, doing, waiting, done.
2. Name the constraint.
3. Name thieves of time.
4. Kill silent WIP.

**Failure modes:**
- A pretty board with hidden work

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
