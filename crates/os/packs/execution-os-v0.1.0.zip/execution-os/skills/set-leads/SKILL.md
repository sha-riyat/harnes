# Skill: set-leads

**Purpose:** Choose lead measures the team can influence.

**When to use:** Only lag trophies are tracked.

**Steps:**
1. Separate lag from lead.
2. Check influenceability.
3. Define a counter-metric.
4. Refuse vanity totals.

**Failure modes:**
- Vanity as lead measure

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
