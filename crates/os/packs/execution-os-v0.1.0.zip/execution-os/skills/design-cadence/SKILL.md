# Skill: design-cadence

**Purpose:** Design a weekly operating cadence.

**When to use:** Strategy exists only as a deck.

**Steps:**
1. Name the WIG or contribution.
2. Set a review that can change resources.
3. Protect maker time.
4. Cancel meetings without a production purpose.

**Failure modes:**
- More meetings as the cadence

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
