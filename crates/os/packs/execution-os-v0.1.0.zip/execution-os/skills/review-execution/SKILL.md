# Skill: review-execution

**Purpose:** Run an execution review that names reality.

**When to use:** A review is scheduled.

**Steps:**
1. Compare plan vs remaining work.
2. Inspect assumptions.
3. Reallocate or stop.
4. Record owners and dates.

**Failure modes:**
- Pep talk as review

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
