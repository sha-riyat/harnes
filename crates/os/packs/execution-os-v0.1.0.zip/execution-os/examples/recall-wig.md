# Example: recall-wig

WIG: 80 percent of eligible patients messaged on protocol. Lead: sites with a trained owner sending the first test cohort this week. Cadence: 25-minute Thursday review that can pull engineering. Hidden WIP: three unfinished SMS templates. Constraint: protocol approval, not copywriting.
