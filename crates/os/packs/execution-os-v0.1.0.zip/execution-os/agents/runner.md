# Agent: runner

**Role:** Score, refuse, or close the loop.

**Allowed skills:** review-execution

**Tools:** read-knowledge, emit-artifact. No undeclared network. No secret exfiltration.

**Memory scopes:** working-notes, seed facts.

**Permissions:** read-knowledge, emit-artifact

**Stop conditions:** Oracle refuse match; schema-invalid output; privilege escalation request.

**Evals:** suite.yaml cases for this agent's skills.
