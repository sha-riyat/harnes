# Working notes — execution-os

Depends on decision-os and goal-life-strategy-os for what is worth executing. project-os consumes this for bounded bets. operations-os owns repeating systems.
