# Managerial leverage

Grove: output is of the organization under influence.
