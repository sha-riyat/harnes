# First principles — execution-os

1. Execution is few scores, a cadence, and a constraint — not more priorities.
2. Lead measures and WIP beat motivational posters.
3. Knowledge work still has a production process (Grove).
4. Checklists catch known failures; they do not invent strategy.
5. Operating reviews decide; status tours do not.
6. Visible work exposes theft of time (queues, blockers).
7. Personal GTD is not an enterprise operating system.
8. Novels (Phoenix, Goal) teach; they are not plant designs.
9. No promised 2x from a framework.
10. Anti-guru: no SEAL/frog/hustle identity as a method.
