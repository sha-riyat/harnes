# People-strategy-operations

Bossidy/Charan: three linked processes, not a strategy offsite.
