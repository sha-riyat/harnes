# Constraint in execution

Goldratt: elevate the constraint; do not balance every local metric.
