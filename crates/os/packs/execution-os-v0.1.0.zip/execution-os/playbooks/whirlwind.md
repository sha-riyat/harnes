# Playbook: whirlwind

If daily operations eat the WIG, shrink the WIG or protect hours. Do not add a thirteenth priority.
