# Playbook: no-hustle

Extreme-ownership posters are not an operating system.
