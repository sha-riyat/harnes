# Execution OS

Wave 5 Operate OS. Convert intent into finished work with cadence, constraints, and visible WIP — not hustle theater, fake grind, or promised velocity.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (28 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: evaluation-os, decision-os, goal-life-strategy-os.
