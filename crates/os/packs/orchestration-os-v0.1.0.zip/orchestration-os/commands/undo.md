# Command /undo

**Use:** Compensate a run.
**Invokes:** compensate
**Input:** run id
**Output artifact type:** compensation-plan
**Refuse when:** no compensation defined and side effects happened
