# Command /compile

**Use:** Compile a workflow.
**Invokes:** compile-workflow
**Input:** goal
**Output artifact type:** workflow-graph
**Refuse when:** no on_fail
