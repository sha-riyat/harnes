# Command /route

**Use:** Route an utterance.
**Invokes:** route-intent
**Input:** text
**Output artifact type:** route-decision
**Refuse when:** empty text
