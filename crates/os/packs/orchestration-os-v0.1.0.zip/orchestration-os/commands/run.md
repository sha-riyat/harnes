# Command /run

**Use:** Run a saga.
**Invokes:** run-saga
**Input:** workflow id
**Output artifact type:** run-record
**Refuse when:** unknown id
