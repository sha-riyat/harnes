Phase 0 orchestration-os. No live engine ships; YAML is the contract.
