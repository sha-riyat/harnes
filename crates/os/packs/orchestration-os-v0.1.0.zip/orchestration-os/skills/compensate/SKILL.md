    # Skill: compensate

    **Purpose:** Apply compensation for a failed or cancelled saga.

    **When to use:** on_fail=compensate or user cancel.

    **Steps:**
    1. Load completed side-effecting steps in reverse.
2. Apply compensation actions.
3. Record leftovers for humans.
4. Never pretend full rollback if not true.

    **Failure modes:**
    - No plan but money moved

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
