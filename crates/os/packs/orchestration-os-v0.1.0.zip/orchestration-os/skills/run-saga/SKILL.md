    # Skill: run-saga

    **Purpose:** Execute steps with records and timeouts.

    **When to use:** Compiled graph.

    **Steps:**
    1. Start run-record.
2. Execute in order/fanout.
3. Honor on_fail.
4. Close record.

    **Failure modes:**
    - Unlogged side effect

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
