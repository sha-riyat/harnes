    # Skill: route-intent

    **Purpose:** Map text or artifact type to a skill, agent, or workflow.

    **When to use:** Inbound request.

    **Steps:**
    1. Match intents.yaml.
2. Pick most specific.
3. If below threshold, clarify or refuse.
4. Log unmatched for librarian-os.

    **Failure modes:**
    - Ambiguous dual match with no priority

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
