    # Skill: compile-workflow

    **Purpose:** Build a valid workflow graph from a goal and available skills.

    **When to use:** New multi-step work.

    **Steps:**
    1. Decompose goal.
2. Assign step kinds.
3. Require on_fail.
4. Validate DAG or bounded loop.

    **Failure modes:**
    - Hidden cycle
- Missing compensation for side effects

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
