# Oracle — orchestration-os

## Defaults
- Workflows are DAGs of typed steps with on_fail.
- Fanout only when independent; join has a timeout.
- Compensation is designed with the happy path.
- Router picks the most specific intent.

## Refuse
- Refuse silent drop of on_fail.
- Refuse distributed locks as the default long-running story.
- Refuse cycles without an explicit iteration budget.

## Precedence
Workflow YAML > improvised agent chat plan.
