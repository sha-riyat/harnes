# Playbook: clarify

Low confidence routes ask one clarifying question, then refuse. They do not guess a mutating workflow.
