# Playbook: join-timeout

Fanout joins wait up to the declared timeout, then on_fail. Partial results are artifacts, not silent drops.
