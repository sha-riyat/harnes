# First principles — orchestration-os

1. Orchestration is who waits, who decides, and what fails closed.
2. Choreography and central control are a choice, not a destiny (Hohpe/Woolf, Newman).
3. Team boundaries are the runtime (Skelton/Pais).
4. Error budgets and ownership beat a DAG screenshot (Beyer).
5. Queues are work; hidden waits are lies.
6. No access bypass via a workflow engine.
7. Humans remain gates where harm is high.
8. No promised autonomous platform.
9. Platform merch can hide missing owners.
10. Anti-guru: no central-brain slide; no Kubernetes-as-strategy.
