# Microservice workflow chapter

Sagas vs distributed transactions; choose explicitly and test the failure path.
