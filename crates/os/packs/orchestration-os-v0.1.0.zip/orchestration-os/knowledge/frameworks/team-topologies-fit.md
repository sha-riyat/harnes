# Ownership of workflows

A workflow that crosses OS boundaries needs a named owning OS. Team Topologies as analogy: stream vs enabling packs.
