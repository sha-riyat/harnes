# DAG with bounded loops

Default acyclic. If a loop is required, attach a budget exactly like agent-os.
