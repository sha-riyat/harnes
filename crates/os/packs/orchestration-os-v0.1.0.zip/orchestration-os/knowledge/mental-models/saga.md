# Saga

Sequence of local transactions with compensations. Use when you cannot have one lock across tools.
