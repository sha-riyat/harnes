# Agent: planner

**Role:** Turns goals into workflow graphs.

**Skills:** compile-workflow, route-intent, run-saga, compensate
**Tools:** none
**Memory scopes:** task, os
**Permissions:** read-knowledge, write-memory
**Handoff:** runner

**Abort conditions:**
- cycle with no budget

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
