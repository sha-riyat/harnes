# Agent: router

**Role:** Intent to workflow/skill.

**Skills:** route-intent, compile-workflow
**Tools:** none
**Memory scopes:** task
**Permissions:** read-knowledge
**Handoff:** planner

**Abort conditions:**
- below min_confidence without clarify

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
