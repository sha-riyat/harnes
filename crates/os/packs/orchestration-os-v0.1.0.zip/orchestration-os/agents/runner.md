# Agent: runner

**Role:** Executes steps and records runs.

**Skills:** run-saga, compensate
**Tools:** none
**Memory scopes:** session, task
**Permissions:** read-knowledge, invoke-tool, write-memory
**Handoff:** planner, human

**Abort conditions:**
- step timeout exceeded twice

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
