# Example: research-then-knowledge

compile-workflow of research-os rapid-evidence then knowledge-builder-os synthesis-to-graph. on_fail compensate: do not promote partial graph.
