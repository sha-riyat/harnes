# Playbook: mom-test

Life, past, specifics. If you hear 'sounds great', you failed the interview, not succeeded.
