# Playbook: commitments

Time, reputation, or money on the table beats compliments. Log them separately.
