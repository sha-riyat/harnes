# Agent: synthesis-clerk

**Role:** Synthesizes notes into killed or surviving assumptions.

**Skills:** synthesize-discovery, diagnose-step
**Tools:** none
**Memory scopes:** os, task
**Permissions:** read-knowledge, write-memory
**Handoff:** discovery-steward

**Abort conditions:**
- treating compliments as commitments

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
