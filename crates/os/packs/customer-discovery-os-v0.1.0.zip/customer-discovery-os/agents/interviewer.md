# Agent: interviewer

**Role:** Designs mom-test questions and recruiting.

**Skills:** map-hypotheses, design-interviews
**Tools:** none
**Memory scopes:** task
**Permissions:** read-knowledge
**Handoff:** discovery-steward

**Abort conditions:**
- pitch disguised as interview

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
