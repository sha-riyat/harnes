# Example: dentist-calendar

Map hypotheses: missed appointments as problem, office manager as user, dentist as buyer. Guide: last three no-shows, current workarounds, who pays. Synthesize: 7/10 have a workaround they hate; 1 offered to trial. Diagnose: still discovery, not creation.
