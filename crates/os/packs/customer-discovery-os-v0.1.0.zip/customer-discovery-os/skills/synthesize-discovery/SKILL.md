    # Skill: synthesize-discovery

    **Purpose:** Synthesize interviews into killed and surviving assumptions.

    **When to use:** Notes from multiple conversations exist.

    **Steps:**
    1. Tag facts, quotes, commitments.
2. Count patterns across people.
3. Kill or keep cards.
4. State next test.

    **Failure modes:**
    - Using the most charming story as the market

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
