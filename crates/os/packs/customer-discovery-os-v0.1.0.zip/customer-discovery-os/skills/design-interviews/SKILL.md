    # Skill: design-interviews

    **Purpose:** Design recruiting and mom-test questions.

    **When to use:** Hypotheses exist and people must be spoken with.

    **Steps:**
    1. Who has the problem now.
2. Learning goals.
3. Past-behavior questions.
4. Forbidden pitch lines.
5. Note-taking template.

    **Failure modes:**
    - Interviewing only friends

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
