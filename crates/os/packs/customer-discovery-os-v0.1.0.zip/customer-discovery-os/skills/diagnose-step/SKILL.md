    # Skill: diagnose-step

    **Purpose:** Diagnose customer-development step: discovery, validation, creation, company-building.

    **When to use:** A team claims to be a startup or a new venture inside a firm.

    **Steps:**
    1. Look at evidence vs spend.
2. See if they are searching or executing.
3. Flag premature scale.
4. Recommend a step-appropriate next move.

    **Failure modes:**
    - Scale spend with untested value hypothesis

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
