    # Skill: map-hypotheses

    **Purpose:** Write problem, customer, and solution hypotheses as killable cards.

    **When to use:** A new offer or a stuck team.

    **Steps:**
    1. Separate problem, segment, channel, revenue.
2. Mark importance vs evidence.
3. Name the riskiest.
4. State the next contact plan.

    **Failure modes:**
    - Solution-only canvas

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
