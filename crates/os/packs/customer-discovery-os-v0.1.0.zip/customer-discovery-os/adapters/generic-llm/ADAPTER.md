# generic-llm adapter — customer-discovery-os

Purpose of this OS: Get out of the building, talk in a way that resists politeness, and log evidence — search, not pitch.

## Mapping
Pack SKILL.md + schemas + oracle excerpts into a single system block. Tools via JSON function-calling if the host supports it; otherwise ask the model to emit typed JSON matching output.schema.json.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
No native long-term memory, no MCP resources, no multi-agent runtime.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
