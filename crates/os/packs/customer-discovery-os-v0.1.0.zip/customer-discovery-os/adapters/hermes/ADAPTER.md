# hermes adapter — customer-discovery-os

Purpose of this OS: Get out of the building, talk in a way that resists politeness, and log evidence — search, not pitch.

## Mapping
Prefer strict JSON mode. Hermes tool-call envelopes wrap tool-integration-os contracts. Keep oracle refuse rules in the preamble.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Does not define Hermes GGUF files or sampler settings.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
