# First principles — customer-discovery-os

1. Talk about their life, not your pitch.
2. Compliments and hypotheticals are weak evidence.
3. Commitment (time, money, intro) beats praise.
4. A problem interview is not a solution interview.
5. Jobs and circumstances beat personas-as-fiction.
6. Founder stories are n=1.
7. Consent and no-leading-questions are method, not niceness.
8. Discovery does not end at launch; it changes cadence.
9. No promised product-market fit date.
10. Anti-guru: no wolf-energy selling dressed as research.
