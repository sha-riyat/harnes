# Switch timeline

When they last switched, what pushed and pulled, what habits held them.
