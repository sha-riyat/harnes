# Four steps

Discovery, validation, creation, company-building. Name the step.
