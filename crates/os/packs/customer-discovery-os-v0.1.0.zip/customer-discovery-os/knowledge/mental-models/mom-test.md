# Mom test

Questions even a supportive parent cannot fluff: their life, their past, their specifics.
