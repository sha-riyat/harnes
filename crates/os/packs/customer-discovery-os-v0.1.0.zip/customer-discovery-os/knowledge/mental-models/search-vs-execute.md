# Search vs execute

A startup searches for a model. A company executes one. Mixing the metrics destroys both.
