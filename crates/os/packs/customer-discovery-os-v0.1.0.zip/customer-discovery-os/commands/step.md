# Command /step

**Use:** Diagnose search vs execute step.
**Invokes:** diagnose-step
**Input:** situation
**Output artifact type:** step-diagnosis
**Refuse when:** scale without evidence
