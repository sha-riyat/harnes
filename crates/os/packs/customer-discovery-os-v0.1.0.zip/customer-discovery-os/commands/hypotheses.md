# Command /hypotheses

**Use:** Map killable hypotheses.
**Invokes:** map-hypotheses
**Input:** idea
**Output artifact type:** hypothesis-map
**Refuse when:** solution-only
