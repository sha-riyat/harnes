# Command /guide

**Use:** Design interview guide.
**Invokes:** design-interviews
**Input:** riskiest assumption
**Output artifact type:** interview-guide
**Refuse when:** friends-only sample as if it were a market
