# Command /synth

**Use:** Synthesize discovery notes.
**Invokes:** synthesize-discovery
**Input:** notes
**Output artifact type:** synthesis-log
**Refuse when:** one anecdote as market
