# Example: recall-ready

Charter risks: wrong patient, silent send failure, accessibility of confirm. Tests: exploratory mis-tap paths, contract checks with SMS vendor sandbox, one production-shaped dry run. Residual: vendor outage owned by ops. Readiness: no-go until wrong-patient path has a confirmation step from security-os/design-os.
