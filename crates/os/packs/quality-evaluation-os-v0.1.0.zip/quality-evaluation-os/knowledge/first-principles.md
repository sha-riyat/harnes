# First principles — quality-evaluation-os

1. Testing is a search for important problems in a context.
2. Perfect software is an illusion; say what you looked for.
3. Oracles and charters are first-class.
4. Automation is an assistant, not a methods exemption.
5. Coverage and velocity numbers can be leprechauns.
6. Exploratory and scripted work pair.
7. SLOs and error budgets are quality contracts in production.
8. Evaluate only systems you are authorized to evaluate.
9. No promised zero-defect.
10. Anti-guru: no coverage theater, no attack kits for others' systems.
