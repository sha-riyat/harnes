# Agile testing quadrants

Guide vs critique; business vs technology. Balance the four.
