# Error budget as quality policy

SRE: reliability target makes ship/no-ship economic, not moral.
