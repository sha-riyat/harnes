# Release It patterns

Timeouts, bulkheads, circuit breakers as testable quality attributes.
