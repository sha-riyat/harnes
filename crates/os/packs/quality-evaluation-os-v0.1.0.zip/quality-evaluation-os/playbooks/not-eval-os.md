# Playbook: not-eval-os

If the subject is an agent prompt or harness rubric, route to Wave 0 evaluation-os. This OS is for shipping products.
