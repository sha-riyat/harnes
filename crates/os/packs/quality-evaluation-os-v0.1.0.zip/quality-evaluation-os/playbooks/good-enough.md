# Playbook: good-enough

Write good-enough in the charter before you argue about more tests.
