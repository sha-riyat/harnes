# Command /charter

**Use:** Write a quality/risk charter.
**Invokes:** risk-charter
**Input:** product + users
**Output artifact type:** risk-charter
**Refuse when:** zero-defect claim
