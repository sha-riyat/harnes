# Command /ready

**Use:** Ship-readiness argument.
**Invokes:** ship-readiness
**Input:** charter + grade
**Output artifact type:** ship-readiness
**Refuse when:** guarantee of perfection
