# Command /grade

**Use:** Grade a build.
**Invokes:** grade-build
**Input:** evidence
**Output artifact type:** build-grade
**Refuse when:** green-CI-as-enough without charter
