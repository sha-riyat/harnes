# Command /tests

**Use:** Design tests for a risk.
**Invokes:** design-test
**Input:** risk
**Output artifact type:** test-design
**Refuse when:** script-only religion
