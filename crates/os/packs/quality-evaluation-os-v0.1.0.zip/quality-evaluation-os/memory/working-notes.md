# Working notes — quality-evaluation-os

Do not merge with evaluation-os. Ship path after readiness is release-os.
