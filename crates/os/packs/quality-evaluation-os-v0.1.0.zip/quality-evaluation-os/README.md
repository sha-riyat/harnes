# Quality Evaluation OS

Wave 3 Build OS. Argue whether a product is good enough to ship — risk charters, test design, build grading, readiness — not Wave 0 harness judges.

Start at OS.md, then oracle/ORACLE.md, then skills/. Research lives in research/books-ranked.yaml (32 ranked titles). Practices are paraphrased on selected ranks 1–4.

Depends on: research-os, evaluation-os.
