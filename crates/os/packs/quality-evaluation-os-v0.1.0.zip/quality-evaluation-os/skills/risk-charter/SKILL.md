# Skill: risk-charter

**Purpose:** Write what good-enough means and which risks matter.

**When to use:** A team is testing without a question.

**Steps:**
1. Name users and harm models.
2. List priority risks.
3. Define good-enough and residual risk owner.
4. Set stop rules.

**Failure modes:**
- Zero-defect slogan

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
