# Skill: ship-readiness

**Purpose:** Write the go/no-go quality argument.

**When to use:** A release is proposed.

**Steps:**
1. Restate residual risks.
2. Confirm stop rules evaluated.
3. Name who accepts residual risk.
4. Hand path-to-prod issues to release-os.

**Failure modes:**
- Guarantee of no incidents

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
