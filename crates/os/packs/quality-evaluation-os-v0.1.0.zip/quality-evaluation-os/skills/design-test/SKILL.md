# Skill: design-test

**Purpose:** Design an investigation for a named risk.

**When to use:** A risk is on the charter.

**Steps:**
1. Restate the risk as a question.
2. Choose exploration, examples, or automated checks.
3. Define oracles.
4. Define when to stop this investigation.

**Failure modes:**
- Coverage number as the only design

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
