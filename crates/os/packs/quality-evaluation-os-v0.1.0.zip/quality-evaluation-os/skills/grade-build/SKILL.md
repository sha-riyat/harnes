# Skill: grade-build

**Purpose:** Grade evidence against the charter.

**When to use:** A candidate build exists.

**Steps:**
1. Map evidence to each charter risk.
2. Downgrade peeked or gamed checks.
3. Separate lab green from production-shaped tests.
4. Give a grade with holes.

**Failure modes:**
- CI green equals ship

**Eval hooks:** schema-valid, oracle-refuse-honored

**Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
