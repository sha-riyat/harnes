# Example: recall-saas

Canvas: clinics as segment, recall as proposition, SMS plus staff workflow as activities, per-location subscription as capture. Fit: job is fill the chair, pain is no-shows. Pattern: subscription SaaS, not a platform. Capture: office manager pays; dentist is economic buyer. Tests go to validation-os.
