# Value proposition canvas

Jobs-pains-gains against relievers and creators. Fit is tested.
