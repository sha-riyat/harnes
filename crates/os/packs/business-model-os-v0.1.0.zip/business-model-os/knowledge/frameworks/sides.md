# Multi-sided design

Who is subsidized, who pays, how quality is governed, what chicken-egg probe comes first.
