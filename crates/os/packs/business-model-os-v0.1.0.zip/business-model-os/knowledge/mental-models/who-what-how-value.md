# Who what how value

St. Gallen compression of architecture. Changing one often forces the rest.
