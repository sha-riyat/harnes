# Nine blocks

Partners, activities, resources, proposition, relationships, channels, segments, costs, revenues. Empty slogans are defects.
