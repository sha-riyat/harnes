# First principles — business-model-os

1. A model is create, deliver, capture — and who pays the hidden cost.
2. A canvas is a hypothesis sheet, not a company.
3. Platforms have sides, chicken-egg, and governance.
4. Open innovation changes the boundary of the firm.
5. Price architecture is part of the model.
6. Extraction and surveillance are models; name them.
7. Public, cooperative, and social models exist; do not pretend only VC canvases do.
8. Unit economics before mythology.
9. No promised invincible company.
10. Anti-guru: no Blitzscaling as destiny.
