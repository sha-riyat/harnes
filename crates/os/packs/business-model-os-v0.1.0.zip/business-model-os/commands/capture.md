# Command /capture

**Use:** Design capture logic.
**Invokes:** design-capture
**Input:** canvas
**Output artifact type:** capture-logic
**Refuse when:** user-count-as-model
