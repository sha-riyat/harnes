# Command /canvas

**Use:** Draft or critique a canvas.
**Invokes:** draft-canvas
**Input:** offer + segment
**Output artifact type:** canvas
**Refuse when:** slogan cells
