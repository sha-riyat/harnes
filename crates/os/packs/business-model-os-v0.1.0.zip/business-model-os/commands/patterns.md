# Command /patterns

**Use:** Search model patterns.
**Invokes:** search-patterns
**Input:** idea
**Output artifact type:** pattern-search
**Refuse when:** uniqueness without search
