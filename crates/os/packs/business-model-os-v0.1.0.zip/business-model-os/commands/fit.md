# Command /fit

**Use:** Check proposition fit.
**Invokes:** check-fit
**Input:** segment + offer
**Output artifact type:** value-fit
**Refuse when:** workshop vote as fit
