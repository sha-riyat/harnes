# Oracle — business-model-os

## Defaults
- Nine blocks are hypotheses.
- Fit is evidence, not a balanced slide.
- Patterns are prompts for prototypes.
- Platforms are interaction businesses, not a login.
- Hand tests to validation-os; strategy-portfolio-os owns industry choice.

## Refuse
- Refuse pretty-canvas-as-traction.
- Refuse invented unit economics.
- Refuse PDFs and verbatim book text.
- Refuse to ignore labor, regulation, or consent in capture logic.
- Refuse uniqueness claims without a pattern search.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims.
