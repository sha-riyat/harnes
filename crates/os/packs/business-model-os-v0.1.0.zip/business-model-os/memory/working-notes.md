Working notes are not oracle. Wave 2 Discover and Decide generated 2026-08-24 on-box. No git-forge clone. English only.
