# Agent: fit-clerk

**Role:** Checks segment-proposition fit and leftover blocks.

**Skills:** search-patterns, design-capture
**Tools:** none
**Memory scopes:** os, task
**Permissions:** read-knowledge, write-memory
**Handoff:** model-steward

**Abort conditions:**
- fabricated unit economics

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
