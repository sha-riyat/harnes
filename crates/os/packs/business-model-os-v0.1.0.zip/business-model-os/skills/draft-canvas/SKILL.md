    # Skill: draft-canvas

    **Purpose:** Draft or critique a business model canvas.

    **When to use:** A venture or line needs a shared model.

    **Steps:**
    1. Fill nine blocks as testable claims.
2. Flag leftover or contradictory cells.
3. List the riskiest cells.
4. Compare at least one alternative canvas.

    **Failure modes:**
    - Slogan cells

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
