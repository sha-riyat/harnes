    # Skill: check-fit

    **Purpose:** Check value-proposition fit to jobs, pains, gains.

    **When to use:** A canvas or offer exists.

    **Steps:**
    1. Jobs, pains, gains from evidence not wish.
2. Map relievers and creators.
3. Flag invented jobs.
4. State tests for fit.

    **Failure modes:**
    - Fit declared from a workshop vote

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
