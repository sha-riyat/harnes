    # Skill: design-capture

    **Purpose:** Design capture: revenue, price, platform sides, or subscription logic.

    **When to use:** Value creation is sketched; capture is vague.

    **Steps:**
    1. Who pays vs who uses.
2. Price architecture.
3. If multi-sided, subsidy side and chicken-egg.
4. Unit-economics hypotheses with confidence grades.
5. Ethics and regulation.

    **Failure modes:**
    - User count as a business model

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
