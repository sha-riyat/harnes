    # Skill: search-patterns

    **Purpose:** Search a pattern library (who/what/how/value) before claiming uniqueness.

    **When to use:** A team says the model is unprecedented.

    **Steps:**
    1. Name the four dimensions.
2. Retrieve close patterns.
3. Note forced moves if one dimension changes.
4. Pick one pattern to prototype.
5. Write kill criteria.

    **Failure modes:**
    - Copy-paste from another industry with no constraint map

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
