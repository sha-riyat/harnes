# Playbook: two-canvases

Always sketch an alternative model, not one pretty page. Comparison is the point.
