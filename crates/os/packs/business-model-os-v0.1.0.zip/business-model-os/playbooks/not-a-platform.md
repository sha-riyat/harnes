# Playbook: not-a-platform

If both sides do not have a reason to show up, it is a pipeline with a forum. Say so.
