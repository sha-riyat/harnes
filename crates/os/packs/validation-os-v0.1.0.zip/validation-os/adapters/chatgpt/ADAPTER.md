# chatgpt adapter — validation-os

Purpose of this OS: Turn hypotheses into experiments with kill rules — from cheap probes to trustworthy tests, never theater.

## Mapping
Use developer instructions for constitution excerpts and tools array for skills that declare tools. File search / retrieval maps to knowledge/ and research/.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Does not set OpenAI API keys or GPTs store listing.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
