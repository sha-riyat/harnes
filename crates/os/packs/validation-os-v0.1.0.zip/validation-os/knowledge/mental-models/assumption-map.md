# Assumption map

Importance on one axis, evidence on the other. Work the important unknowns.
