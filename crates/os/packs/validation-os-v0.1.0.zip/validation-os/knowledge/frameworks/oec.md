# Overall evaluation criterion

One primary metric plus guardrails so local hacks cannot win.
