# Desirability viability feasibility

Three hypothesis families. Do not test only the fun one.
