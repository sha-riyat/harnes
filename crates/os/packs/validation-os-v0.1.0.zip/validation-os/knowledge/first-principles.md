# First principles — validation-os

1. A test is a bet with a sample, a clock, and a kill rule.
2. Peeking, optional stopping, and novelty effects lie.
3. Online A/B is not the only identification strategy.
4. Pretotypes test demand cheaper than code.
5. Guardrails belong on the card.
6. Base rates before the inside story of a lift.
7. Ethics: no dark-pattern experiments on captive users without a bar.
8. Empty or null results are products.
9. No promised growth from a landing page.
10. Anti-guru: no p-hack theater.
