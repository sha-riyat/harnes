    # Skill: map-assumptions

    **Purpose:** Map desirability, viability, feasibility assumptions by importance and evidence.

    **When to use:** A canvas or idea needs tests.

    **Steps:**
    1. Split D/V/F.
2. Score importance.
3. Score evidence.
4. Pick the top-right unknown.
5. Write a next test type.

    **Failure modes:**
    - All assumptions marked validated by gut

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
