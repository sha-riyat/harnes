    # Skill: pivot-review

    **Purpose:** Run a scheduled pivot or persevere review.

    **When to use:** A cycle of tests completed.

    **Steps:**
    1. Restate the value and growth hypotheses.
2. Show the evidence log.
3. Options: persevere, pivot, pause, kill.
4. Do not decide from mood.

    **Failure modes:**
    - Infinite persevere without thresholds

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
