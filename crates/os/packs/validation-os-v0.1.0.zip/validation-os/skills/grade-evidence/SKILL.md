    # Skill: grade-evidence

    **Purpose:** Grade evidence strength after a test.

    **When to use:** Results arrived.

    **Steps:**
    1. Check instrumentation bugs (including sample ratio issues on online tests).
2. Separate learning from vanity.
3. Grade A-E.
4. Recommend escalate fidelity, kill, or continue.

    **Failure modes:**
    - Unusual metric jump with no QA

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
