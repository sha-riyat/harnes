    # Skill: design-experiment

    **Purpose:** Design an experiment card with metric and kill rule.

    **When to use:** A riskiest assumption is named.

    **Steps:**
    1. Hypothesis in falsifiable form.
2. Method at the right fidelity.
3. Metric and sample honesty.
4. Kill/continue threshold.
5. Ethics check.

    **Failure modes:**
    - Method that cannot falsify the claim

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
