# Research methodology — validation-os

Questions: which books in this domain are real, publisher-checkable, and usable by an operator? which titles overclaim?

Method: keep the existing verified ranked list; add only titles with checkable author, year, and publisher; omit if uncertain. Paraphrase practices. Grade A-E. No PDFs. No fabricated books. No GitHub clone.

Deepen wave 2-3: target about 50 real books; 10 paraphrased practices on each of ranks 1-15; refresh first principles, contradictions, and ontology from the extraction.

Exclusions: guru merch as methods; success guarantees; invented citations; for security-os, exploit recipes and access bypass.
