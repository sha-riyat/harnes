# Playbook: kill-rule

If you cannot write what would make you stop, you are decorating a decision already made.
