# Playbook: cheap-then-strong

Landing-page smoke tests before industrial A/B. Do not wait for a platform to start learning, and do not treat a smoke test as a CUP-grade experiment.
