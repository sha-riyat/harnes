# Example: clinic-sms

Assumption: SMS 24h before cuts no-shows. Design: randomized 400 visits, primary metric show-rate, guardrail unsubscribe. Kill if lift less than 2 points. Grade instrumentation. Review: persevere only if effect holds a second week.
