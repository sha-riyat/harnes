# Command /grade

**Use:** Grade evidence.
**Invokes:** grade-evidence
**Input:** result
**Output artifact type:** evidence-grade
**Refuse when:** no-QA miracle lift
