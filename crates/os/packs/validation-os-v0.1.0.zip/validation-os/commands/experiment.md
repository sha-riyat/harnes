# Command /experiment

**Use:** Design experiment card.
**Invokes:** design-experiment
**Input:** hypothesis
**Output artifact type:** experiment-card
**Refuse when:** unfalsifiable method
