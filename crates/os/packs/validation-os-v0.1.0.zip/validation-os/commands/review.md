# Command /review

**Use:** Pivot or persevere review.
**Invokes:** pivot-review
**Input:** evidence log
**Output artifact type:** pivot-review
**Refuse when:** no-threshold persevere
