# Command /assumptions

**Use:** Map assumptions.
**Invokes:** map-assumptions
**Input:** idea
**Output artifact type:** assumption-map
**Refuse when:** gut-validated
