# claude adapter — brainstorm-os

Purpose of this OS: Run structured ideation with deferred judgment, then screen ideas — never confuse fluency with evidence.

## Mapping
Use a system prompt assembled from OS.md + oracle/ORACLE.md. Tools map to Claude tool specs. Artifacts return as structured blocks, not chatty prose.

## Context packing
Order: constitution excerpt → oracle → active skill contract → retrieved knowledge hits → task artifact.

## Permissions
The host must enforce the agent permission list. This adapter never grants extra capabilities.

## Unsupported
Does not set Anthropic API keys or org policies.

## Smoke check
Load manifest.yaml, lint the OS, invoke one skill with a fixture from examples/, validate output against output.schema.json.
