# Playbook: solo-then-combine

If politics is high, generate silently first, then hitchhike. Do not worship the original Osborn group-only ritual.
