# Playbook: defer-then-kill

Protect green time. Then black-hat with teeth. A group that never kills is not creative; it is indecisive.
