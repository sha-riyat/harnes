# Command /frame

**Use:** Frame the ideation problem.
**Invokes:** frame-problem
**Input:** brief
**Output artifact type:** problem-frame
**Refuse when:** solution-only pitch
