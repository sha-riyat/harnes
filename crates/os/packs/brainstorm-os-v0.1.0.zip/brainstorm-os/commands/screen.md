# Command /screen

**Use:** Screen ideas to a probe set.
**Invokes:** screen-ideas
**Input:** ideas + constraints
**Output artifact type:** shortlist
**Refuse when:** screen as market proof
