# Command /hats

**Use:** Parallel thinking pass.
**Invokes:** hat-pass
**Input:** idea list
**Output artifact type:** hat-pass
**Refuse when:** hats as personality labels
