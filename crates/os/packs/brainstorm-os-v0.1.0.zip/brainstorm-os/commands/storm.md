# Command /storm

**Use:** Generate ideas with deferred judgment.
**Invokes:** generate-ideas
**Input:** frame + technique
**Output artifact type:** idea-set
**Refuse when:** evaluation during generation
