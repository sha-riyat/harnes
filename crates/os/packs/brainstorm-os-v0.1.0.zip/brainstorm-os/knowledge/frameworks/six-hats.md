# Six hats sequence

Blue owns order. Never skip white facts or black risks on high-stakes choices.
