# CPS lineage

Clarify, ideate, develop, implement. Brainstorming is one cell.
