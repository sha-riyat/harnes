# First principles — brainstorm-os

1. Defer judgment while generating; evaluate later, separately.
2. Quantity is a path, not a personality.
3. Individual incubation plus combination often beats only group shouting.
4. Name the problem before the storm.
5. Techniques are drills, not a muse-wait.
6. Constraints can generate.
7. Facilitation protects time and safety.
8. Unstructured brainstorming can underperform; treat Osborn as history plus a method, not a law.
9. A later screen is part of the process.
10. Anti-guru: no creativity-as-identity merch.
