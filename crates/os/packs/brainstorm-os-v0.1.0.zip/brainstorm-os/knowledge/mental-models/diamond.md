# Divergent-convergent diamond

Widen, then narrow. Skipping either is a defect.
