# Generate then judge

Two clocks. First clock forbids critique. Second clock requires it.
