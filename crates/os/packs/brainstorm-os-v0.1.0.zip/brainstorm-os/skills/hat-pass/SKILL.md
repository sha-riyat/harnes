    # Skill: hat-pass

    **Purpose:** Run a parallel-thinking pass over an idea set.

    **When to use:** Ideas exist and the group is arguing in mixed modes.

    **Steps:**
    1. White: facts missing.
2. Red: feelings as data.
3. Yellow/black: plus/minus.
4. Green: variants.
5. Blue: sequence and decision.

    **Failure modes:**
    - Using hats to label people

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
