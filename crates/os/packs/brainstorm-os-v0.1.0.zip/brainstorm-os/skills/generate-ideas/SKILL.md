    # Skill: generate-ideas

    **Purpose:** Run deferred-judgment generation with a named technique.

    **When to use:** A framed problem exists.

    **Steps:**
    1. Pick a technique (storm, reversal, random entry, attribute list).
2. Time-box.
3. Forbid evaluation talk.
4. Capture all items.
5. Stop at saturation.

    **Failure modes:**
    - Evaluation leaking into generation

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
