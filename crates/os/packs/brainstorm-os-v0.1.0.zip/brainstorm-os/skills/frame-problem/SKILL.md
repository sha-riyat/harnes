    # Skill: frame-problem

    **Purpose:** Rewrite the challenge so ideation has a job.

    **When to use:** A team wants ideas but the brief is a slogan.

    **Steps:**
    1. Extract the current brief.
2. Ask what would count as a better problem.
3. List constraints that are real vs fake.
4. Emit a how-might-we plus stop conditions.

    **Failure modes:**
    - No problem exists, only a solution in search of a pitch

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
