    # Skill: screen-ideas

    **Purpose:** Screen ideas against constraints without fake scoring precision.

    **When to use:** After generation, a shortlist is needed.

    **Steps:**
    1. Restate constraints.
2. Kill illegal or out-of-scope items.
3. Cluster.
4. Pick a probe set, not a winner-for-life.
5. Hand off to tests.

    **Failure modes:**
    - Treating screen as validation

    **Eval hooks:** schema-valid, oracle-refuse-honored

    **Abort:** If input fails schema, if required citations are missing when the skill claims evidence, or if a refuse rule in oracle/ORACLE.md matches.
