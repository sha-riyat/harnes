# Agent: facilitator

**Role:** Runs generation and parallel-thinking passes.

**Skills:** frame-problem, generate-ideas
**Tools:** none
**Memory scopes:** task
**Permissions:** read-knowledge
**Handoff:** ideation-steward

**Abort conditions:**
- request to skip screening forever

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
