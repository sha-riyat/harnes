# Agent: screen-clerk

**Role:** Screens ideas against constraints without killing novelty too early.

**Skills:** hat-pass, screen-ideas
**Tools:** none
**Memory scopes:** os, task
**Permissions:** read-knowledge, write-memory
**Handoff:** ideation-steward

**Abort conditions:**
- use hats as personality labels

**Loop:** perceive → retrieve (context-memory policy) → act via listed skills → emit artifact → eval gate → stop or continue within budget 8 steps.
