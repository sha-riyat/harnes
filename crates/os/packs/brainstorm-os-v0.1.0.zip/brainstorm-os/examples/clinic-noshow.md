# Example: clinic-noshow

Frame no-shows as a job (remember, travel, fear). Silent generate 15 minutes, hitchhike, hat-pass, screen to three probes for validation-os. Do not ship the funniest sticky note.
