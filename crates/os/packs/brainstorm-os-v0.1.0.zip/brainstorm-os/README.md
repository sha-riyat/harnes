# Brainstorm OS

Run structured ideation with deferred judgment, then screen ideas — never confuse fluency with evidence.

Wave 2 Discover and Decide OS. Load `manifest.yaml`. Doctrine in `OS.md`. Judgments in `oracle/ORACLE.md`.

Depends on: research-os, evaluation-os.

Confidence: B. Quality target ≥90, floor 7 per category.

## Quick start
1. Lint: `python3 scripts/lint-os.py --os brainstorm-os`
2. Route an intent from `routing/intents.yaml`
3. Run a skill under `skills/`
4. Score with `evals/suite.yaml`
