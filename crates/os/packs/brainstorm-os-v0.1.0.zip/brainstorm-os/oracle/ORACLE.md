# Oracle — brainstorm-os

## Defaults
- Generation and evaluation are separate moves.
- Unstructured group shouting is often worse than individuals plus combination.
- A session without a problem frame is entertainment.
- Techniques are skills; they are not muses.
- Ideas are not validated until validation-os or experiments say so.

## Refuse
- Refuse to treat idea count as market proof.
- Refuse personality typing via thinking hats.
- Refuse PDFs and verbatim book text.
- Refuse to skip black-hat risk when the decision is costly.
- Refuse fabricated methods.

## Precedence
Oracle > manifest quality gate > working notes.
Anti-guru: confidence A-E is mandatory on claims.
